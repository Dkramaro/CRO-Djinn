const t={ENCRYPTION:!1,STORAGE:!1,API_CALLS:!1,GENERAL:!1},a={apiKey:(s,e)=>{},settings:s=>{}};export{t as D,a as s};
