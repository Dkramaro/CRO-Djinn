import{S as l}from"./storage.js";import{D as g}from"./debug.js";import"./encryption.js";class p{static async hasConsent(e){try{const t=this.getConsentKey(e),s=(await chrome.storage.local.get(t))[t];if(!s)return!1;const o=Date.now(),n=s.timestamp+this.CONSENT_EXPIRY_DAYS*24*60*60*1e3;return o>n?(await chrome.storage.local.remove(t),!1):s.granted}catch{return!1}}static async saveConsent(e,t){try{const i=this.getConsentKey(e),s={domain:e,granted:t,timestamp:Date.now()};await chrome.storage.local.set({[i]:s})}catch(i){throw i}}static async showConsentDialog(e){return new Promise(t=>{const i=document.createElement("div");i.style.cssText=`
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.7);
        z-index: 999999;
        display: flex;
        align-items: center;
        justify-content: center;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      `;const s=document.createElement("div");s.style.cssText=`
        background: white;
        border-radius: 8px;
        padding: 24px;
        max-width: 480px;
        margin: 20px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        text-align: center;
        line-height: 1.5;
      `,s.innerHTML=`
        <div style="margin-bottom: 16px;">
          <h3 style="margin: 0 0 12px 0; color: #1f2937; font-size: 18px;">
            🔒 Privacy Notice
          </h3>
          <p style="margin: 0; color: #4b5563; font-size: 14px;">
            CRO Djinn wants to analyze this page (<strong>${e}</strong>) to provide conversion optimization recommendations.
          </p>
        </div>
        
        <div style="background: #f3f4f6; padding: 16px; border-radius: 6px; margin: 16px 0; text-align: left;">
          <p style="margin: 0 0 8px 0; font-weight: 600; color: #374151; font-size: 13px;">
            What data will be collected:
          </p>
          <ul style="margin: 0; padding-left: 20px; color: #6b7280; font-size: 12px;">
            <li>Page content and structure</li>
            <li>Button and form elements</li>
            <li>Page screenshots (if enabled)</li>
          </ul>
          <p style="margin: 8px 0 0 0; color: #6b7280; font-size: 12px;">
            Data is sent to AI services (OpenAI/Google) for analysis and stored locally on your device.
          </p>
        </div>

        <div style="display: flex; gap: 12px; justify-content: center;">
          <button id="consent-deny" style="
            background: #e5e7eb;
            color: #374151;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
          ">
            Don't Analyze
          </button>
          <button id="consent-allow" style="
            background: #3b82f6;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
          ">
            Allow Analysis
          </button>
        </div>
        
        <p style="margin: 16px 0 0 0; color: #9ca3af; font-size: 11px;">
          Consent expires in 30 days. You can manage data in the extension settings.
        </p>
      `,i.appendChild(s),document.body.appendChild(i);const o=s.querySelector("#consent-allow"),n=s.querySelector("#consent-deny");o.addEventListener("click",()=>{document.body.removeChild(i),t(!0)}),n.addEventListener("click",()=>{document.body.removeChild(i),t(!1)}),i.addEventListener("click",a=>{a.target===i&&(document.body.removeChild(i),t(!1))});const r=a=>{a.key==="Escape"&&(document.body.removeChild(i),document.removeEventListener("keydown",r),t(!1))};document.addEventListener("keydown",r)})}static async clearAllConsents(){try{const e=await chrome.storage.local.get(),t=Object.keys(e).filter(i=>i.startsWith(this.CONSENT_KEY_PREFIX));t.length>0&&await chrome.storage.local.remove(t)}catch(e){throw e}}static async getGrantedConsents(){try{const e=await chrome.storage.local.get(),t=[];for(const[i,s]of Object.entries(e))if(i.startsWith(this.CONSENT_KEY_PREFIX)){const o=s;o.granted&&t.push(o.domain)}return t}catch{return[]}}static getConsentKey(e){return`${this.CONSENT_KEY_PREFIX}${e}`}static getDomainFromUrl(e){try{return new URL(e).hostname}catch{return e}}}p.CONSENT_KEY_PREFIX="consent_";p.CONSENT_EXPIRY_DAYS=30;class f{constructor(){this.form=null,this.providerSelect=null,this.openaiApiKeyInput=null,this.geminiApiKeyInput=null,this.openaiModelSelect=null,this.geminiModelSelect=null,this.fullPageScreenshotCheckbox=null,this.openaiConfig=null,this.geminiConfig=null,this.saveButton=null,this.cacheCountElement=null,this.consentsCountElement=null,this.initializeOptions()}async initializeOptions(){try{this.setupElements(),this.setupEventListeners(),await this.loadSettings(),await this.updateCacheInfo(),await this.updatePrivacyInfo()}catch{this.showError("Failed to load settings")}}setupElements(){if(this.providerSelect=document.getElementById("provider-select"),this.openaiApiKeyInput=document.getElementById("openai-api-key"),this.geminiApiKeyInput=document.getElementById("gemini-api-key"),this.openaiModelSelect=document.getElementById("openai-model"),this.geminiModelSelect=document.getElementById("gemini-model"),this.fullPageScreenshotCheckbox=document.getElementById("full-page-screenshot"),this.openaiConfig=document.getElementById("openai-config"),this.geminiConfig=document.getElementById("gemini-config"),this.saveButton=document.getElementById("save-button"),this.cacheCountElement=document.getElementById("cache-count"),this.consentsCountElement=document.getElementById("consents-count"),!this.providerSelect||!this.openaiApiKeyInput||!this.geminiApiKeyInput||!this.openaiModelSelect||!this.geminiModelSelect||!this.fullPageScreenshotCheckbox||!this.saveButton||!this.openaiConfig||!this.geminiConfig)throw new Error("Required form elements not found")}setupEventListeners(){var o,n,r,a;(o=this.saveButton)==null||o.addEventListener("click",c=>{c.preventDefault(),this.saveSettings()}),(n=this.providerSelect)==null||n.addEventListener("change",()=>{this.handleProviderChange()});const e=document.getElementById("clear-cache-button");e==null||e.addEventListener("click",()=>{this.clearCache()});const t=document.getElementById("clear-consents-button");t==null||t.addEventListener("click",()=>{this.clearConsents()});const i=document.getElementById("clear-all-data-button");i==null||i.addEventListener("click",()=>{this.clearAllData()});const s=document.getElementById("diagnostic-button");s&&s.addEventListener("click",()=>{this.runDiagnostics()}),(r=this.openaiApiKeyInput)==null||r.addEventListener("input",()=>{this.validateForm()}),(a=this.geminiApiKeyInput)==null||a.addEventListener("input",()=>{this.validateForm()}),document.addEventListener("keydown",c=>{c.key==="Enter"&&(c.ctrlKey||c.metaKey)&&this.saveSettings()})}handleProviderChange(){var t,i,s,o,n;const e=(t=this.providerSelect)==null?void 0:t.value;e==="openai"?((i=this.openaiConfig)==null||i.classList.remove("hidden"),(s=this.geminiConfig)==null||s.classList.add("hidden")):e==="gemini"&&((o=this.openaiConfig)==null||o.classList.add("hidden"),(n=this.geminiConfig)==null||n.classList.remove("hidden")),this.validateForm()}async loadSettings(){try{const e=await l.getSettings();this.providerSelect&&(this.providerSelect.value=e.provider||"openai"),this.openaiApiKeyInput&&(this.openaiApiKeyInput.value=e.openaiApiKey||""),this.geminiApiKeyInput&&(this.geminiApiKeyInput.value=e.geminiApiKey||""),this.openaiModelSelect&&(this.openaiModelSelect.value=e.openaiModel||"gpt-5.1"),this.geminiModelSelect&&(this.geminiModelSelect.value=e.geminiModel||"gemini-3-flash-preview"),this.fullPageScreenshotCheckbox&&(this.fullPageScreenshotCheckbox.checked=e.fullPageScreenshot??!0),this.handleProviderChange(),this.validateForm()}catch{this.showError("Failed to load saved settings")}}async saveSettings(){var e,t,i,s,o,n;if(this.validateForm())try{this.setLoading(!0),this.hideMessages();const r=((e=this.providerSelect)==null?void 0:e.value)||"openai",a=await l.getSettings(),c=r!=="openai"?a.openaiApiKey:"",h=r!=="gemini"?a.geminiApiKey:"";if(c&&(typeof c!="string"||c==="[object Object]"))throw new Error("Stored OpenAI API key is corrupted. Please re-enter it on the OpenAI provider settings.");if(h&&(typeof h!="string"||h==="[object Object]"))throw new Error("Stored Gemini API key is corrupted. Please re-enter it on the Gemini provider settings.");const d={provider:r,openaiApiKey:r==="openai"?((t=this.openaiApiKeyInput)==null?void 0:t.value.trim())||"":c,geminiApiKey:r==="gemini"?((i=this.geminiApiKeyInput)==null?void 0:i.value.trim())||"":h,openaiModel:((s=this.openaiModelSelect)==null?void 0:s.value)||"gpt-5.1",geminiModel:((o=this.geminiModelSelect)==null?void 0:o.value)||"gemini-3-flash-preview",fullPageScreenshot:((n=this.fullPageScreenshotCheckbox)==null?void 0:n.checked)||!1};g.STORAGE;const u=r==="openai"?d.openaiApiKey:d.geminiApiKey;if(!this.isValidApiKey(u,r)){const y=r==="openai"?"OpenAI":"Gemini";throw new Error(`Please enter a valid ${y} API key`)}await this.testApiKey(u,r==="openai"?d.openaiModel:d.geminiModel,r),await l.saveSettings(d),this.showSuccess("Settings saved successfully!")}catch(r){const a=r instanceof Error?r.message:"Failed to save settings";this.showError(a)}finally{this.setLoading(!1)}}async testApiKey(e,t,i){var s,o;if(i==="openai"){const n=await fetch("https://api.openai.com/v1/models",{method:"GET",headers:{Authorization:`Bearer ${e}`,"Content-Type":"application/json"}});if(!n.ok)throw n.status===401?new Error("Invalid OpenAI API key. Please check your key."):n.status===429?new Error("OpenAI API rate limit exceeded. Please try again later."):new Error(`OpenAI API test failed (${n.status}). Please check your API key.`);(((s=(await n.json()).data)==null?void 0:s.map(c=>c.id))||[]).includes(t)}else{const n=await fetch("https://generativelanguage.googleapis.com/v1beta/models",{method:"GET",headers:{"Content-Type":"application/json","x-goog-api-key":e}});if(!n.ok)throw n.status===401||n.status===403?new Error("Invalid Gemini API key. Please check your key."):n.status===429?new Error("Gemini API rate limit exceeded. Please try again later."):new Error(`Gemini API test failed (${n.status}). Please check your API key.`);(((o=(await n.json()).models)==null?void 0:o.map(c=>c.name.split("/").pop()))||[]).includes(t)}}async updateCacheInfo(){try{const e=await l.getCacheSize();this.cacheCountElement&&(this.cacheCountElement.textContent=`${e} audits`)}catch{this.cacheCountElement&&(this.cacheCountElement.textContent="Unknown")}}async clearCache(){try{if(!confirm("Are you sure you want to clear all cached audit results? This action cannot be undone."))return;await l.clearCache(),await this.updateCacheInfo(),this.showSuccess("Cache cleared successfully!")}catch{this.showError("Failed to clear cache")}}async updatePrivacyInfo(){try{const e=await p.getGrantedConsents();this.consentsCountElement&&(this.consentsCountElement.textContent=`${e.length} sites`)}catch{this.consentsCountElement&&(this.consentsCountElement.textContent="Unknown")}}async clearConsents(){try{if(!confirm("Are you sure you want to clear all site consents? You will be prompted for consent again on all websites."))return;await p.clearAllConsents(),await this.updatePrivacyInfo(),this.showSuccess("Site consents cleared successfully!")}catch{this.showError("Failed to clear site consents")}}async clearAllData(){try{if(!confirm(`⚠️ WARNING: This will delete ALL extension data including API keys, settings, cached results, and site consents. This action cannot be undone.

Are you sure you want to continue?`))return;await Promise.all([p.clearAllConsents(),l.clearCache(),chrome.storage.sync.clear(),chrome.storage.local.clear()]),this.showSuccess("All extension data deleted successfully! Page will reload to reset settings."),setTimeout(()=>{window.location.reload()},2e3)}catch{this.showError("Failed to delete all extension data")}}async runDiagnostics(){try{const t=(await chrome.storage.sync.get("extension_settings")).extension_settings,i=await l.getSettings();g.STORAGE;const s=l.validateSettings(i),o=i.provider,n=o==="openai"?i.openaiApiKey:i.geminiApiKey,r=this.isValidApiKey(n,o);let a=`🔍 Diagnostics Results:

`;if(a+=`Provider: ${o}
`,a+=`Current API Key Valid: ${r?"✅ YES":"❌ NO"}
`,a+=`Current API Key Length: ${(n==null?void 0:n.length)||0}

`,r?(a+=`✅ Your API key appears to be valid.
`,a+="If you're still having issues, there might be a network or API quota problem."):(a+=`❌ Issue Detected: Your ${o.toUpperCase()} API key appears to be corrupted.

`,a+=`Recommended Actions:
`,a+=`1. Re-enter your API key manually
`,a+=`2. Make sure it starts with "${o==="openai"?"sk-":"AIza"}"
`,a+=`3. Or clear all data and start fresh

`,a+="Check browser console for detailed logs."),alert(a),!r&&confirm("Would you like to attempt automatic repair of the corrupted API key? If that fails, we can clear all settings and start fresh."))try{await this.attemptSettingsRepair(),this.showSuccess("Settings repair attempted. Please check if your API key is working now.")}catch{confirm("Automatic repair failed. Would you like to clear all corrupted settings? This will reset your API keys and you'll need to re-enter them.")&&(await chrome.runtime.sendMessage({type:"CLEAR_CORRUPTED_SETTINGS"}),this.showSuccess("Corrupted settings cleared. Please re-enter your API keys."),setTimeout(()=>{window.location.reload()},1500))}}catch{this.showError("Failed to run diagnostics. Check console for details.")}}async attemptSettingsRepair(){try{const t=(await chrome.storage.sync.get("extension_settings")).extension_settings;if(!t)throw new Error("No settings found to repair");const i={...t};let s=!1;i.openaiApiKey&&typeof i.openaiApiKey!="string"&&(i.openaiApiKey=String(i.openaiApiKey),s=!0),i.geminiApiKey&&typeof i.geminiApiKey!="string"&&(i.geminiApiKey=String(i.geminiApiKey),s=!0),s&&(await chrome.storage.sync.set({extension_settings:i}),await this.loadSettings())}catch(e){throw e}}validateForm(){var i,s,o;const e=(i=this.providerSelect)==null?void 0:i.value;let t=!1;if(e==="openai"){const n=((s=this.openaiApiKeyInput)==null?void 0:s.value.trim())||"";t=this.isValidApiKey(n,"openai")}else if(e==="gemini"){const n=((o=this.geminiApiKeyInput)==null?void 0:o.value.trim())||"";t=this.isValidApiKey(n,"gemini")}return this.saveButton&&(this.saveButton.disabled=!t),t}isValidApiKey(e,t){return!e||e.length===0?!1:t==="openai"?e.startsWith("sk-")&&e.length>20:e.startsWith("AIza")&&e.length>30}setLoading(e){if(!this.saveButton)return;const t=this.saveButton.querySelector(".button-text"),i=this.saveButton.querySelector(".loading-spinner");e?(this.saveButton.disabled=!0,t==null||t.classList.add("hidden"),i==null||i.classList.remove("hidden")):(this.saveButton.disabled=!1,t==null||t.classList.remove("hidden"),i==null||i.classList.add("hidden"))}showSuccess(e){this.hideMessages();const t=document.getElementById("success-message");t&&(t.classList.remove("hidden"),setTimeout(()=>{t.classList.add("hidden")},4e3))}showError(e){this.hideMessages();const t=document.getElementById("error-message"),i=document.getElementById("error-text");t&&i&&(i.textContent=e,t.classList.remove("hidden"))}hideMessages(){const e=document.getElementById("success-message"),t=document.getElementById("error-message");e==null||e.classList.add("hidden"),t==null||t.classList.add("hidden")}}document.addEventListener("DOMContentLoaded",()=>{new f});
