import{_ as j}from"./preload-helper.js";import{D as w}from"./debug.js";console.log("🔧 [Offscreen] Document loaded at:",location.href);console.log("🔧 [Offscreen] chrome object available:",!!chrome);console.log("🔧 [Offscreen] chrome.storage available:",!!(chrome!=null&&chrome.storage));var U;console.log("🔧 [Offscreen] chrome.storage.local available:",!!((U=chrome==null?void 0:chrome.storage)!=null&&U.local));console.log("🔧 [Offscreen] chrome.runtime available:",!!(chrome!=null&&chrome.runtime));globalThis.__OFFSCREEN_INIT__||(globalThis.__OFFSCREEN_INIT__=!0,console.log(`🔧 [Offscreen] Document loading at: ${location.href}`),setTimeout(async()=>{var e,t;console.log("🔧 [Offscreen] Delayed check - chrome.storage.local available:",!!((e=chrome==null?void 0:chrome.storage)!=null&&e.local)),(t=chrome==null?void 0:chrome.storage)!=null&&t.local?(console.log("✅ [Offscreen] chrome.storage.local is directly available"),x()):(console.log("📡 [Offscreen] chrome.storage not available - using proxy mode through background script"),console.log("🔧 [Offscreen] Available chrome APIs:",chrome?Object.keys(chrome):"chrome is undefined"),x())},100));function x(){console.log("🔧 [Offscreen] Document initializing with direct storage pattern..."),chrome.runtime.onMessage.addListener((e,t,s)=>{var a;return(e==null?void 0:e.type)==="RUN_ANALYSIS"?(console.log("[Offscreen] Received RUN_ANALYSIS:",e.payload),B(e.payload).then(()=>{var n;console.log(`✅ [Offscreen] Analysis completed successfully for ${(n=e.payload)==null?void 0:n.key}`)},async n=>{var p;const c=((p=e.payload)==null?void 0:p.key)||"unknown";console.error(`❌ [Offscreen] Analysis failed for ${c}:`,n);try{await chrome.runtime.sendMessage({type:"STORAGE_SET",key:`job:${c}`,data:{key:c,state:"failed",updatedAt:Date.now(),error:String((n==null?void 0:n.message)||n),failedAt:Date.now()}})}catch(i){console.error("❌ [Offscreen] Failed to write error state to storage:",i)}}),s({ok:!0}),!0):(e==null?void 0:e.type)==="COMPRESS_IMAGE"?(console.log("[Offscreen] Received COMPRESS_IMAGE request",{dataLength:((a=e.base64Data)==null?void 0:a.length)||0,targetRatio:e.targetRatio||.35}),(async()=>{try{if(!e.base64Data||typeof e.base64Data!="string")throw new Error("Invalid base64Data provided");const n=await G(e.base64Data,e.targetRatio||.5);console.log("[Offscreen] Image compression successful"),s({ok:!0,compressedData:n})}catch(n){console.error("[Offscreen] Image compression failed:",n),console.warn("[Offscreen] Falling back to original image data"),s({ok:!1,error:String(n),compressedData:e.base64Data})}})(),!0):(e==null?void 0:e.type)==="TEST_CONNECTION"?(console.log("[Offscreen] Received TEST_CONNECTION"),s({ok:!0,message:"Offscreen document ready"}),!0):e.type==="OFFSCREEN_ANALYZE"?(console.warn("[Offscreen] Ignoring legacy OFFSCREEN_ANALYZE message"),s({success:!1,error:"Use RUN_ANALYSIS instead"}),!0):!1}),console.log("✅ [Offscreen] Document ready for RUN_ANALYSIS requests")}async function D(e,t,s){var p,i,g,m,f,r,l,h,d,y,E,A,v,O,C,b,N,$,P,R,k,L,M;const a=`llm_${Date.now()}_${Math.random().toString(36).substr(2,9)}`;console.log(`🤖 [${a}] Starting LLM analysis with ${s.length} screenshots`);const n=`You are a $10,000/day Senior Conversion Rate Optimization Consultant with 20+ years of experience across ALL industries who avoids redundant repitition of recommendations. You've optimized pages for Fortune 500 companies and generated millions in additional revenue through conversion optimization.

YOUR EXPERTISE AREAS:
- Consumer Psychology & Behavioral Economics across different industries and purchase types
- A/B Testing & Statistical Analysis for various business models
- UX/UI Conversion Design tailored to specific page types and user journeys
- Industry-Specific Copywriting & Messaging Strategy
- Trust & Credibility Optimization per business type
- Performance Optimization for different conversion goals

CRITICAL FIRST STEP - CONTEXT ANALYSIS:
Before making ANY recommendations, you MUST first analyze and determine:

1. BUSINESS TYPE & INDUSTRY: Identify the specific business type (SaaS, E-commerce, Lead Generation, B2B Services, Healthcare, Financial Services, Education, etc.) and apply industry-specific CRO knowledge and benchmarks.

2. PAGE TYPE: Determine what type of page this is:
   - Homepage (brand introduction, multiple conversion paths)
   - Product/Service Page (specific offering focus)
   - Landing Page (single conversion goal, campaign-driven)
   - Pricing Page (purchase decision, plan comparison)
   - About/Contact Page (trust building, lead generation)
   - Blog/Content Page (engagement, nurturing)

3. PURCHASE BEHAVIOR TYPE: Assess whether this is:
   - HIGH-CONSIDERATION PURCHASE: Complex, expensive, or high-risk decisions requiring extensive research, social proof, detailed information, and trust building (B2B software, expensive products, professional services, medical/legal services).
   - IMPULSE/LOW-CONSIDERATION PURCHASE: Quick, low-risk decisions that benefit from urgency, scarcity, and streamlined checkout (consumer products, low-cost items, entertainment, basic services).

INDUSTRY-SPECIFIC ANALYSIS REQUIREMENTS:
- Apply industry-specific conversion psychology and benchmarks.
- Reference industry-standard conversion rates and best practices.
- Use terminology and value propositions relevant to that industry.
- Consider industry-specific trust signals and objections.
- Apply appropriate urgency and scarcity tactics for that market.

PAGE TYPE-SPECIFIC ANALYSIS:
- Tailor recommendations to the page's primary conversion goal.
- Consider the user's mindset and intent when landing on this page type.
- Apply appropriate conversion frameworks for the page type.
- Adjust recommendation priorities based on page function.

PURCHASE BEHAVIOR ADAPTATION:
- For HIGH-CONSIDERATION: Focus on trust building, detailed information, social proof, risk reduction, consultative approach, longer-form content, multiple touchpoints.
- For IMPULSE/LOW-CONSIDERATION: Focus on simplicity, speed, urgency, clear CTAs, streamlined process, immediate gratification.

CUSTOMER JOURNEY MAPPING REQUIREMENTS:
- Start with the visitor's entry point (search intent, traffic source, mindset)
- Map each section of the page in sequence as the customer scrolls
- Identify decision points and conversion moments throughout the page
- Note potential friction points and drop-off areas
- End with the primary conversion action and next steps
- Use numbered steps that reflect the actual page flow and content order
- Dont be overly detailed, just enough to get the point across, 1 sentence per step.

ANALYSIS DEPTH REQUIRED: Your analysis must be comprehensive enough to justify a $10,000+ consulting fee. Every recommendation must be:
1. Backed by industry-specific conversion psychology principles.
2. Tailored to the identified page type and user intent.
3. Appropriate for the purchase behavior type (high vs low consideration).
4. Include detailed step-by-step implementation instructions in the "implementation" array.
5. Prioritized by conversion impact potential for this specific context.
6. Supported by industry-specific benchmarks and best practices.

IMPLEMENTATION REQUIREMENT: Every recommendation MUST include 3-5 specific, actionable implementation steps that they can execute immediately.

OUTPUT QUALITY: This analysis should read like a professional consulting report that demonstrates deep understanding of the specific industry, page type, and customer psychology.`,c=`COMPREHENSIVE CRO AUDIT REQUEST: Conduct a detailed, professional-grade conversion optimization analysis worth $10,000+ in consulting value.

=== PAGE CONTEXT ===
PAGE TITLE: ${e.title}
URL: ${e.url}
META DESCRIPTION: ${e.metaDescription}
VIEWPORT: ${e.pageMetadata.viewport.width}x${e.pageMetadata.viewport.height}
PAGE HEIGHT: ${e.pageMetadata.viewport.scrollHeight}px
MOBILE OPTIMIZED: ${e.pageMetadata.viewportMeta.includes("width=device-width")?"Yes":"No"}

=== COMPLETE PAGE CONTENT ===
${e.fullTextContent}

=== STRUCTURAL ANALYSIS ===
CONTENT HIERARCHY:
${e.structuredContent.headings.map(o=>{const u=o.position||{top:0},S=e.pageMetadata.viewport.height||800,T=u.top<S?"Above fold":u.top<S*2?"Mid-page":"Below fold";return`${o.tag.toUpperCase()}: "${o.text}" (${T})`}).join(`
`)}

INTERACTIVE ELEMENTS (Buttons, CTAs, Links):
${e.structuredContent.interactiveElements.map(o=>{const u=o.isAboveFold?"Above fold":"Below fold",S=o.position.width*o.position.height,T=S>8e3?"Large":S>3e3?"Medium":"Small";return`${o.elementType==="button"?"BUTTON":"LINK"} (${T}, ${u}): "${o.text}"${o.href?` -> ${o.href}`:""}`}).join(`
`)}

${((i=(p=e.structuredContent)==null?void 0:p.forms)==null?void 0:i.length)>0?`
CONVERSION FORMS:
${e.structuredContent.forms.map((o,u)=>`Form ${u+1}: ${o.totalFields||0} fields (${o.requiredFields||0} required), Action: "${o.action||"No action"}"`).join(`
`)}`:""}

${((m=(g=e.structuredContent)==null?void 0:g.lists)==null?void 0:m.length)>0?`
CONTENT LISTS:
${e.structuredContent.lists.map(o=>{var u;return`${((u=o.tag)==null?void 0:u.toUpperCase())||"UNKNOWN"}: ${o.itemCount||0} items`}).join(`
`)}`:""}

${((r=(f=e.structuredContent)==null?void 0:f.videos)==null?void 0:r.length)>0||((h=(l=e.structuredContent)==null?void 0:l.images)==null?void 0:h.filter(o=>o.isAnimated).length)>0?`
MEDIA ELEMENTS:
${((y=(d=e.structuredContent)==null?void 0:d.videos)==null?void 0:y.length)>0?e.structuredContent.videos.map(o=>{var T;const u=o.src.includes("youtube")?"YouTube":o.src.includes("vimeo")?"Vimeo":o.src.includes("wistia")?"Wistia":o.src.includes("loom")?"Loom":o.type==="video"?"Native Video":"Video",S=[o.autoplay?"autoplay":"",o.muted?"muted":"",o.controls?"has-controls":"no-controls",o.loop?"looping":""].filter(Boolean).join(", ");return`${(T=o.type)==null?void 0:T.toUpperCase()}: ${u} (${S}) - ${o.width}x${o.height}px - ${o.parentSection||"Unknown section"}`}).join(`
`):""}${((A=(E=e.structuredContent)==null?void 0:E.videos)==null?void 0:A.length)>0&&((O=(v=e.structuredContent)==null?void 0:v.images)==null?void 0:O.filter(o=>o.isAnimated).length)>0?`
`:""}${((b=(C=e.structuredContent)==null?void 0:C.images)==null?void 0:b.filter(o=>o.isAnimated).length)>0?`Animated Images (GIFs): ${e.structuredContent.images.filter(o=>o.isAnimated).map(o=>o.parentSection||"Unknown").join(", ")}`:""}`:""}
${(($=(N=e.structuredContent)==null?void 0:N.interactive)==null?void 0:$.length)>0?`
INTERACTIVE ELEMENTS:
${e.structuredContent.interactive.map(o=>{var u;return`${((u=o.type)==null?void 0:u.toUpperCase())||"CAROUSEL"}: ${o.itemCount||0} items${o.hasControls?" (Has navigation)":""}${o.hasDots?" (Has dots)":""} - ${o.parentSection||"Unknown section"}`}).join(`
`)}`:""}

PAGE FLOW:
${((R=(P=e.structuredContent)==null?void 0:P.sections)==null?void 0:R.slice(0,8).map((o,u)=>{var S;return`Section ${u+1}: "${((S=o.textPreview)==null?void 0:S.substring(0,80))||"No preview"}..."`}).join(`
`))||"NO PAGE SECTIONS"}

${(L=(k=e.structuredContent)==null?void 0:k.stickyHeader)!=null&&L.exists?`
STICKY HEADER DETECTED:
Position Type: ${e.structuredContent.stickyHeader.positionType}
Total Height: ${e.structuredContent.stickyHeader.totalHeight}px
Element Count: ${e.structuredContent.stickyHeader.elementCount}
Contents: ${((M=e.structuredContent.stickyHeader.contents)==null?void 0:M.map(o=>`${o.tag.toUpperCase()} (${o.height}px)${o.ctas.length>0?` - CTAs: ${o.ctas.join(", ")}`:""}`).join(" | "))||"No content details available"}

** IMPORTANT: This page ALREADY HAS a sticky/fixed header that follows users on scroll. Do NOT recommend adding a sticky header. Only make a recommendation IF the current design and CTA prominence is insufficient for maximizing conversions based on your assessment, when evaluating this leverage the screenshots to determine this.
`:`
NO STICKY/FIXED HEADER DETECTED:
This page does not currently have a sticky or fixed header that follows users on scroll. Depending on the page type, length, and conversion goals, this may be an opportunity to add one with a clear CTA.
`}

=== ANALYSIS REQUIREMENTS ===

CRITICAL REQUIREMENTS:
- Only analyze elements that actually exist on the page - do NOT invent or hallucinate content
- NEVER include percentage improvement estimates or conversion lift numbers
- Focus on unique, actionable insights - avoid repeating the same recommendations across sections
- If no forms exist, omit the forms section entirely
- Each recommendation should be distinct and non-overlapping to avoid redundancy
- Do NOT use em Dashes in the analysis


INTERACTIVE ELEMENT ANALYSIS:
- You are receiving ALL interactive elements (buttons and links) without pre-filtering
- Use the full page context with the screenshots to visually confirm, element size, position, and styling to determine:
  * Which are primary CTAs (likely large buttons above fold with action-oriented copy)
  * Which are secondary CTAs (smaller, less prominent, or below fold)
  * Which are navigation elements (links in header/footer, standard nav patterns)
  * Which are trust signals (Contact, About, Support in appropriate contexts)
  * Which are social proof (social media links, review platform links)
- Consider the business type and page type when classifying element importance

ANALYSIS STRUCTURE:

1. **CONTEXT ANALYSIS FIRST** (Mandatory)
   - Identify business type/industry and apply industry-specific expertise
   - Determine page type and adapt analysis framework accordingly  
   - Assess purchase behavior type (high vs low consideration) and tailor approach
   - Establish industry-specific benchmarks and best practices

2. **PAGE SUMMARY** 
   - Business type, audience, and conversion goals with industry context
   - Page type and its role in the conversion funnel
   - Purchase behavior analysis and implications
   - Detailed customer journey analysis: Start with how customers arrive at this page, then map each step they take through the page content toward conversion, including decision points and potential drop-off areas
   - Top 3 strengths and top 3 weaknesses

3. **VISUAL CRO ANALYSIS** (For Visual Analysis Only)
    ${s.length>0?`=== VISUAL ANALYSIS ===
    You have access to ${s.length>1?`${s.length} sequential screenshots of the complete page from top to bottom`:"a screenshot of the page"} to supplement the analysis. Use ${s.length>1?"these":"this"} to analyze:
    - Visual hierarchy and user flow
    - CTA prominence and placement
    - Design quality, consistency, and trust signals
    - Color scheme effectiveness
    - Overall visual polish
    
    IMPORTANT: When analyzing videos, carousels, and interactive elements:
    - Native video players may show a poster frame or first frame; this does NOT mean they're broken.
    - Videos with visible controls or play buttons are functional.
    - Carousels may appear static in screenshots but are functional if navigation controls are present.
    - Animated GIFs may appear as static images but are functional on the live page`:""}

   As a $10,000/day CRO auditor, provide dedicated visual conversion analysis:
   - VISUAL FLOW ANALYSIS: How does the eye naturally flow through the page? Do colors and content hierarchy guide users toward CTAs? Are there visual distractions that pull attention away from conversion goals?
   - COLOR & CONTRAST EVALUATION: How effective are the color choices for conversion? Is there sufficient contrast for readability and CTA prominence? Do colors create the right emotional response for the target audience?
   - CRITICAL VISUAL ISSUE: What's the single biggest visual problem preventing conversions? Focus on business impact and user behavior. Provide clear, non-technical solutions that marketers and executives can understand and implement. Avoid technical details like hex codes, pixel measurements, or CSS specifications. Instead, describe the problem in terms of user experience and business outcomes, then provide simple, actionable solutions that can be communicated to designers and developers, avoid repitition with other recommendations.
   - You should verify your ideas from Context Analysis to inform these recommendations.

4. **ACTIONABLE RECOMMENDATIONS** 
   - 5-7 prioritized, industry-specific recommendations with detailed step-by-step implementation
   - Each recommendation MUST include an "implementation" array with 3-5 specific, actionable steps
   - Psychological principles behind each recommendation (adapted for purchase behavior type)
   - Effort level and timeline for each
   - Industry-specific best practices and benchmarks
   - Compelling emotionally & logically charged copy suggestions
   - You should verify your ideas from Visual CRO Analysis to inform these recommendations

5. **QUICK WINS**
   - 3-5 high-impact, low-effort improvements that can be done immediately
   - Tailored to the specific page type and business model
   - Avoid repitition with other recommendations


CRITICAL: 
- Each recommendation MUST include a detailed "implementation" array with step-by-step instructions.
- You CANNOT include redundancies in the recommendations.

Return analysis as JSON with this ENHANCED structure:
{
  "starRating": 2,
  "pageSummary": {
    "businessType": "B2B SaaS - Project Management Software",
    "industryContext": "High-consideration B2B software purchase requiring trust building and detailed feature explanation",
    "pageType": "Pricing Page",
    "purchaseBehaviorType": "high-consideration",
    "primaryConversionGoal": "Upgrade to paid plan or start trial", 
    "targetAudience": "Team leaders and project managers at mid-size companies",
    "currentUserJourney": [
      "1. Arrive on page (likely from search for ADHD symptoms/clinics)",
      "2. Identify with common ADHD symptoms and challenges",
      "3. Understand the problem of undiagnosed ADHD and traditional care barriers", 
      "4. Learn how Frida provides a solution (online, accessible, affordable)",
      "5. Review social proof and success stories",
      "6. Understand the 'how it works' process",
      "7. Evaluate expert credentials and service offerings",
      "8. Consider pricing and FAQs",
      "9. Take the 'Free ADHD Symptoms Test' as a low-commitment first step"
    ],
    "keyStrengths": ["Clear pricing tiers", "Industry-standard features", "Professional design"],
    "criticalWeaknesses": ["Weak social proof for enterprise segment", "No risk mitigation messaging", "Missing implementation support details"]
  },
  "visualCROAnalysis": {
    "visualFlow": {
      "eyeFlowPath": "Hero → Value Prop → Social Proof → CTA",
      "flowScore": 7,
      "guidesToCTA": true,
      "distractions": ["Competing CTAs in sidebar", "Too many color variations"]
    },
    "colorContrast": {
      "ctaContrast": "Excellent - 4.8:1 ratio",
      "readability": "Good overall", 
      "emotionalResponse": "Trust-building blues with conversion-optimized orange CTAs",
      "contrastScore": 8
    },
    "criticalIssue": {
      "problem": "Primary CTA blends with background reducing click-through rates",
      "solution": "Make the main call-to-action button stand out with a contrasting color that draws attention. Use a bright, action-oriented color that creates visual separation from the background. Ensure the button text is clearly readable and the overall design encourages clicks.",
      "impact": "High - likely 15-20% conversion increase",
      "urgency": "Critical"
    }
  },
  "recommendations": [
    {
      "title": "Add Enterprise Social Proof Section",
      "priority": "critical",
      "issue": "B2B buyers need validation from similar companies before committing to paid plans",
      "solution": "Create dedicated section with enterprise customer logos, case studies, and ROI metrics specific to project management efficiency",
      "implementation": [
        "Step 1: Collect customer success metrics and testimonials from existing clients",
        "Step 2: Design a dedicated social proof section to place above the pricing table",
        "Step 3: Add customer logos, case studies, and specific ROI data points",
        "Step 4: Include industry-specific benchmarks and success metrics",
        "Step 5: Test placement and messaging for maximum impact"
      ],
      "psychologyBehind": "B2B high-consideration purchases require social proof from peers to reduce perceived risk and validate decision-making",
      "industryContext": "SaaS pricing pages convert 23% better with prominent customer logos and specific ROI metrics",
      "effort": 3,
      "timeline": "1-2 weeks"
    }
  ],
  "quickWins": [
    {
      "title": "Add Risk-Free Trial Messaging",
      "description": "Emphasize 'No credit card required' and 'Cancel anytime' messaging prominently near CTAs",
      "rationale": "Reduces commitment anxiety for high-consideration purchases",
      "effort": 1,
      "timeline": "Same day"
    }
  ],
  "executiveSummary": [
    "Context: B2B SaaS pricing page for high-consideration software purchase requiring trust and risk mitigation",
    "Key insight: Missing critical trust signals and implementation clarity needed for enterprise buyers",
    "Priority focus: Add enterprise social proof and implementation support messaging to reduce buyer anxiety",
    "Industry benchmark: Current approach missing 40% of conversion elements typical in high-converting B2B SaaS pricing pages"
  ],
  "copySuggestions": [
    {
      "section": "Primary CTA",
      "suggestion": "Start Free Trial - No Credit Card Required"
    },
    {
      "section": "Risk Mitigation", 
      "suggestion": "Join 2,500+ teams already saving 40% on project delivery time"
    }
  ]
}

STAR RATING CRITERIA:
⭐ (1 Star) - Major Issues: 5+ critical problems, missing basic conversion elements (clear value prop, primary CTA, trust signals), poor UX/mobile experience, not optimized for industry/page type
⭐⭐ (2 Stars) - Good Foundation: 4-5 significant opportunities, basic elements present but not optimized for industry/purchase behavior, decent user experience but missing key conversion triggers
⭐⭐⭐ (3 Stars) - Well Optimized: 1-3 minor improvements possible, strong industry-appropriate conversion fundamentals, good psychology implementation, well-designed for target audience and page type`;if(console.log(`🤖 [${a}] Making API call to ${t.provider.toUpperCase()}`),t.provider==="gemini"){const o=await F(n,c,s,t);return console.log(`🤖 [${a}] Gemini API call completed successfully`),o}else{const o=await H(n,c,s,t);return console.log(`🤖 [${a}] OpenAI API call completed successfully`),o}}async function F(e,t,s,a){var l,h,d,y,E;const n=a.geminiModel,c=a.geminiApiKey,i=[{text:`${e}

${t}`}];s.forEach(A=>{i.push({inline_data:{mime_type:"image/jpeg",data:A}})});const g={contents:[{parts:i}],generationConfig:{temperature:.3,maxOutputTokens:16384,responseMimeType:"application/json"}},m=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${n}:generateContent?key=${c}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(g)});if(!m.ok){const A=await m.text();throw new Error(`Gemini API error (${m.status}): ${A}`)}const r=((E=(y=(d=(h=(l=(await m.json()).candidates)==null?void 0:l[0])==null?void 0:h.content)==null?void 0:d.parts)==null?void 0:y[0])==null?void 0:E.text)||"";if(r.length===0)throw new Error("Empty response from Gemini API");try{return JSON.parse(r)}catch(A){console.error("JSON parsing error:",A);const v=_(r);if(v)try{return JSON.parse(v)}catch(O){console.error("Repaired JSON also failed to parse:",O)}throw new Error(`Invalid JSON response from Gemini API: ${A instanceof Error?A.message:"Parse failed"}`)}}async function H(e,t,s,a){var r,l,h;const n=a.openaiModel,c=a.openaiApiKey,p=[{type:"text",text:`${e}

${t}`}];s.forEach(d=>{p.push({type:"image_url",image_url:{url:`data:image/jpeg;base64,${d}`,detail:"low"}})});const i={model:n,messages:[{role:"user",content:p}]};n.startsWith("gpt-5")?(i.max_completion_tokens=16384,i.response_format={type:"json_object"}):n.includes("gpt-4")||n.includes("gpt-3.5")?(i.max_tokens=16384,i.temperature=.3,i.response_format={type:"json_object"}):(i.max_tokens=16384,i.temperature=.3,i.response_format={type:"json_object"});const g=await fetch("https://api.openai.com/v1/chat/completions",{method:"POST",headers:{Authorization:`Bearer ${c}`,"Content-Type":"application/json"},body:JSON.stringify(i)});if(!g.ok){const d=await g.text();throw new Error(`OpenAI API error (${g.status}): ${d}`)}const f=((h=(l=(r=(await g.json()).choices)==null?void 0:r[0])==null?void 0:l.message)==null?void 0:h.content)||"";if(f.length===0)throw new Error("Empty response from OpenAI API");try{return JSON.parse(f)}catch(d){console.error("JSON parsing error:",d);const y=_(f);if(y)try{return JSON.parse(y)}catch(E){console.error("Repaired JSON also failed to parse:",E)}throw new Error(`Invalid JSON response from OpenAI API: ${d instanceof Error?d.message:"Parse failed"}`)}}function _(e){try{console.log("Attempting to repair truncated JSON...");let t=e.trim();if(!t.startsWith("{")){const p=t.indexOf("{");if(p===-1)return null;t=t.substring(p)}let s=0,a=0,n=!1,c=!1;for(let p=0;p<t.length;p++){const i=t[p];if(c){c=!1;continue}if(i==="\\"){c=!0;continue}if(i==='"'&&!c){n=!n;continue}n||(i==="{"?s++:i==="}"?s--:i==="["?a++:i==="]"&&a--)}if(n){const p=t.lastIndexOf('"');p>0&&(t=t.substring(0,p+1))}for(;a>0;)t+="]",a--;for(;s>0;)t+="}",s--;return JSON.parse(t),console.log("Repaired JSON is valid!"),t}catch(t){return console.log("JSON repair failed:",t),null}}async function G(e,t=.5){try{const s=Math.floor(e.length*.75);console.log(`[Offscreen] Starting compression of ${Math.round(s/1024)}KB image`);const a=document.createElement("canvas"),n=a.getContext("2d");if(!n)throw new Error("Canvas context not available");const c=new Image;await new Promise((d,y)=>{c.onload=()=>d(),c.onerror=()=>y(new Error("Failed to load image for compression")),c.src=`data:image/png;base64,${e}`}),console.log(`[Offscreen] Original image dimensions: ${c.width}x${c.height}`);const p=Math.sqrt(t),i=Math.floor(c.width*p),g=Math.floor(c.height*p);console.log(`[Offscreen] Target compressed dimensions: ${i}x${g} (${Math.round(p*100)}% scale)`),a.width=i,a.height=g,n.imageSmoothingEnabled=!0,n.imageSmoothingQuality="high",n.drawImage(c,0,0,i,g);const m=.5,r=a.toDataURL("image/jpeg",m).replace(/^data:image\/jpeg;base64,/,""),l=Math.floor(r.length*.75),h=l/s;return console.log(`[Offscreen] Compression complete: ${Math.round(s/1024)}KB → ${Math.round(l/1024)}KB (${Math.round((1-h)*100)}% reduction, actual ratio: ${Math.round(h*100)}%)`),r}catch(s){return console.warn("[Offscreen] Screenshot compression failed, returning original:",s),e}}async function B({key:e,url:t,model:s,params:a}){console.log(`🚀 [Offscreen] Starting analysis for key: ${e}`);try{await I(e,{state:"running",progress:{step:"Preparing analysis",pct:10}}),await I(e,{progress:{step:"Capturing page data",pct:15}});const n=await K(t);await I(e,{progress:{step:"Capturing screenshots",pct:25}});const c=await z(a);await I(e,{progress:{step:"Analyzing with AI...",pct:40}});const p=await W({pageData:n,url:t,model:s,params:a,screenshots:c});await I(e,{progress:{step:"Finalizing analysis",pct:90}}),await I(e,{state:"succeeded",progress:{step:"Analysis complete",pct:100},result:p,completedAt:Date.now()}),console.log(`✅ [Offscreen] Analysis completed for key: ${e}`),setTimeout(async()=>{try{await chrome.runtime.sendMessage({type:"STORAGE_REMOVE",key:`job:${e}`}),console.log(`🗑️ [Offscreen] TTL cleanup for key: ${e}`)}catch(i){console.warn(`⚠️ [Offscreen] TTL cleanup failed for key: ${e}`,i)}},2*24*60*60*1e3)}catch(n){throw console.error(`❌ [Offscreen] Analysis failed for key: ${e}`,n),await I(e,{state:"failed",error:String(n instanceof Error?n.message:n),failedAt:Date.now()}),n}}async function Y(e){try{const t=await chrome.runtime.sendMessage({type:"STORAGE_GET",key:`job:${e}`});if(t!=null&&t.ok)return t.data||{key:e,createdAt:Date.now(),updatedAt:Date.now()};throw new Error((t==null?void 0:t.error)||"Storage proxy failed")}catch(t){return console.error(`❌ [Offscreen] getState failed for key ${e}:`,t),{key:e,createdAt:Date.now(),updatedAt:Date.now()}}}async function I(e,t){try{const a={...await Y(e),...t,updatedAt:Date.now()},n=await chrome.runtime.sendMessage({type:"STORAGE_SET",key:`job:${e}`,data:a});if(n!=null&&n.ok)return console.log(`[Offscreen] State updated via proxy for ${e}:`,t),a;throw new Error((n==null?void 0:n.error)||"Storage proxy failed")}catch(s){throw console.error(`❌ [Offscreen] writeState failed for key ${e}:`,s),s}}async function K(e){console.log(`📄 [Offscreen] Requesting page scraping for: ${e}`);try{const t=await chrome.runtime.sendMessage({type:"SCRAPE_PAGE",url:e});if(t!=null&&t.ok)return console.log(`📄 [Offscreen] Page scraping successful: ${t.data.title}`),t.data;throw new Error((t==null?void 0:t.error)||"Page scraping failed")}catch(t){return console.error("❌ [Offscreen] Page scraping failed:",t),{url:e,title:`Error scraping ${new URL(e).hostname}`,timestamp:Date.now(),metaDescription:"",fullHTML:"",fullTextContent:`Failed to scrape ${e}: ${t instanceof Error?t.message:"Unknown error"}`,pageMetadata:{viewport:{width:1920,height:1080,scrollHeight:2e3},viewportMeta:""},structuredContent:{headings:[],buttons:[],forms:[],links:[],lists:[],sections:[],images:[],stickyHeader:{exists:!1,type:null,height:0,elements:[]}}}}}async function z(e){console.log("📸 [Offscreen] Requesting screenshot capture:",e);try{const t=await chrome.runtime.sendMessage({type:"CAPTURE_SCREENSHOTS",params:e});return t!=null&&t.ok?(console.log(`📸 [Offscreen] Screenshot capture successful: ${t.screenshots.length} images`),t.screenshots):(console.warn(`⚠️ [Offscreen] Screenshot capture failed: ${t==null?void 0:t.error}`),(t==null?void 0:t.screenshots)||[])}catch(t){return console.error("❌ [Offscreen] Screenshot capture failed:",t),[]}}async function W({pageData:e,url:t,model:s,params:a,screenshots:n}){var c,p;console.log(`🤖 [Offscreen] Calling LLM model: ${s} for URL: ${t}`);try{console.log("🤖 [Offscreen] Getting settings via storage proxy...");const i=await chrome.runtime.sendMessage({type:"STORAGE_SYNC_GET",key:"extension_settings"});if(!(i!=null&&i.ok))throw new Error("Failed to get settings via storage proxy");let m={...{provider:"openai",openaiModel:"gpt-5",geminiModel:"gemini-2.5-pro",fullPageScreenshot:!0,openaiApiKey:"",geminiApiKey:""},...i.data||{}};w.STORAGE;const{EncryptionManager:f}=await j(()=>import("./encryption.js"),["./encryption.js","./debug.js"],import.meta.url),r=await f.decryptSettings(m);if(w.STORAGE,w.API_CALLS,r.openaiApiKey&&typeof r.openaiApiKey!="string")throw console.error("🔥 FATAL: OpenAI API key is corrupted (not a string):",{type:typeof r.openaiApiKey}),new Error("OpenAI API key is corrupted in storage. Please go to extension settings and re-enter your API key.");if(r.geminiApiKey&&typeof r.geminiApiKey!="string")throw console.error("🔥 FATAL: Gemini API key is corrupted (not a string):",{type:typeof r.geminiApiKey}),new Error("Gemini API key is corrupted in storage. Please go to extension settings and re-enter your API key.");if(r.openaiApiKey==="[object Object]")throw console.error('🔥 FATAL: OpenAI API key is the literal string "[object Object]"'),new Error("OpenAI API key is corrupted. Please clear extension data and re-enter your API key.");if(r.geminiApiKey==="[object Object]")throw console.error('🔥 FATAL: Gemini API key is the literal string "[object Object]"'),new Error("Gemini API key is corrupted. Please clear extension data and re-enter your API key.");console.log("🤖 [Offscreen] Settings retrieved:",{provider:r.provider,hasApiKey:!!(r.openaiApiKey||r.geminiApiKey),openaiKeyLength:((c=r.openaiApiKey)==null?void 0:c.length)||0,geminiKeyLength:((p=r.geminiApiKey)==null?void 0:p.length)||0,openaiKeyType:typeof r.openaiApiKey,geminiKeyType:typeof r.geminiApiKey,rawSettingsData:i.data});const l=r.provider==="gemini"?r.geminiApiKey:r.openaiApiKey;if(!l)throw new Error(`${r.provider==="gemini"?"Gemini":"OpenAI"} API key not configured`);if(typeof l!="string")throw console.error("🤖 [Offscreen] API key is not a string:",{provider:r.provider,apiKeyType:typeof l,apiKeyValue:l,stringified:String(l)}),new Error(`Invalid API key format: ${typeof l}. Expected string but got ${typeof l}.`);if(r.provider==="openai"){if(!l.startsWith("sk-")||l.length<20)throw console.error("Invalid OpenAI API key format:",{apiKeyType:typeof l,startsWithSk:l.startsWith("sk-"),length:l.length}),new Error('Invalid OpenAI API key format. Key should start with "sk-" and be at least 20 characters long.')}else if(r.provider==="gemini"&&(!l.startsWith("AIza")||l.length<30))throw console.error("Invalid Gemini API key format:",{apiKeyType:typeof l,startsWithAIza:l.startsWith("AIza"),length:l.length}),new Error('Invalid Gemini API key format. Key should start with "AIza" and be at least 30 characters long.');console.log(`🤖 [Offscreen] API key validation passed for ${r.provider}`),w.API_CALLS;const d=await D(e,r,n);return console.log(`✅ [Offscreen] LLM call completed for: ${t}`),d}catch(i){throw console.error("❌ [Offscreen] LLM call failed:",i),new Error(`LLM analysis failed: ${i instanceof Error?i.message:"Unknown error"}`)}}
