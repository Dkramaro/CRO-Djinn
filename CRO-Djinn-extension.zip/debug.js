const s={ENCRYPTION:!1,STORAGE:!1,API_CALLS:!1,GENERAL:!1},a={apiKey:()=>{},settings:()=>{}};export{s as D,a as s};
