import{_}from"./preload-helper.js";import{D as w}from"./debug.js";function U(e){if(!e||typeof e!="string")return String(e);let t=e;return t=t.replace(/sk-[a-zA-Z0-9_-]{20,}/g,"sk-***"),t=t.replace(/AIza[a-zA-Z0-9_-]{20,}/g,"AIza***"),t=t.replace(/Bearer\s+[^\s"']+/gi,"Bearer ***"),t=t.replace(/Authorization:\s*[^\s"']+/gi,"Authorization: ***"),t=t.replace(/x-goog-api-key:\s*[^\s"']+/gi,"x-goog-api-key: ***"),t}globalThis.__OFFSCREEN_INIT__||(globalThis.__OFFSCREEN_INIT__=!0,setTimeout(async()=>{var e;(e=chrome==null?void 0:chrome.storage)!=null&&e.local,x()},100));function x(){chrome.runtime.onMessage.addListener((e,t,s)=>(e==null?void 0:e.type)==="RUN_ANALYSIS"?(F(e.payload).then(()=>{},async o=>{var r;const n=((r=e.payload)==null?void 0:r.key)||"unknown";try{await chrome.runtime.sendMessage({type:"STORAGE_SET",key:`job:${n}`,data:{key:n,state:"failed",updatedAt:Date.now(),error:String((o==null?void 0:o.message)||o),failedAt:Date.now()}})}catch{}}),s({ok:!0}),!0):(e==null?void 0:e.type)==="COMPRESS_IMAGE"?((async()=>{try{if(!e.base64Data||typeof e.base64Data!="string")throw new Error("Invalid base64Data provided");const o=await D(e.base64Data,e.targetRatio||.5);s({ok:!0,compressedData:o})}catch(o){s({ok:!1,error:String(o),compressedData:e.base64Data})}})(),!0):(e==null?void 0:e.type)==="TEST_CONNECTION"?(s({ok:!0,message:"Offscreen document ready"}),!0):e.type==="OFFSCREEN_ANALYZE"?(s({success:!1,error:"Use RUN_ANALYSIS instead"}),!0):!1)}async function H(e,t,s){var r,p,a,u,c,d,h,y,A,m,g,T,E,S,v,b,O,N,R,P,k,$,M;`${Date.now()}${Math.random().toString(36).substr(2,9)}`;const o=`You are a $10,000/day Senior Conversion Rate Optimization Consultant with 20+ years of experience across ALL industries who avoids redundant repitition of recommendations. You've optimized pages for Fortune 500 companies and generated millions in additional revenue through conversion optimization.

YOUR EXPERTISE AREAS:
- Consumer Psychology & Behavioral Economics across different industries and purchase types
- A/B Testing & Statistical Analysis for various business models
- UX/UI Conversion Design tailored to specific page types and user journeys
- Industry-Specific Copywriting & Messaging Strategy
- Trust & Credibility Optimization per business type
- Performance Optimization for different conversion goals

CRITICAL FIRST STEP - CONTEXT ANALYSIS:
Before making ANY recommendations, you MUST first analyze and determine:

1. BUSINESS TYPE & INDUSTRY: Identify the specific business type (SaaS, E-commerce, Lead Generation, B2B Services, Healthcare, Financial Services, Education, etc.) and apply industry-specific CRO knowledge and benchmarks.

2. PAGE TYPE: Determine what type of page this is:
   - Homepage (brand introduction, multiple conversion paths)
   - Product/Service Page (specific offering focus)
   - Landing Page (single conversion goal, campaign-driven)
   - Pricing Page (purchase decision, plan comparison)
   - About/Contact Page (trust building, lead generation)
   - Blog/Content Page (engagement, nurturing)

3. PURCHASE BEHAVIOR TYPE: Assess whether this is:
   - HIGH-CONSIDERATION PURCHASE: Complex, expensive, or high-risk decisions requiring extensive research, social proof, detailed information, and trust building (B2B software, expensive products, professional services, medical/legal services).
   - IMPULSE/LOW-CONSIDERATION PURCHASE: Quick, low-risk decisions that benefit from urgency, scarcity, and streamlined checkout (consumer products, low-cost items, entertainment, basic services).

INDUSTRY-SPECIFIC ANALYSIS REQUIREMENTS:
- Apply industry-specific conversion psychology and benchmarks.
- Reference industry-standard conversion rates and best practices.
- Use terminology and value propositions relevant to that industry.
- Consider industry-specific trust signals and objections.
- Apply appropriate urgency and scarcity tactics for that market.

PAGE TYPE-SPECIFIC ANALYSIS:
- Tailor recommendations to the page's primary conversion goal.
- Consider the user's mindset and intent when landing on this page type.
- Apply appropriate conversion frameworks for the page type.
- Adjust recommendation priorities based on page function.

PURCHASE BEHAVIOR ADAPTATION:
- For HIGH-CONSIDERATION: Focus on trust building, detailed information, social proof, risk reduction, consultative approach, longer-form content, multiple touchpoints.
- For IMPULSE/LOW-CONSIDERATION: Focus on simplicity, speed, urgency, clear CTAs, streamlined process, immediate gratification.

CUSTOMER JOURNEY MAPPING REQUIREMENTS:
- Start with the visitor's entry point (search intent, traffic source, mindset)
- Map each section of the page in sequence as the customer scrolls
- Identify decision points and conversion moments throughout the page
- Note potential friction points and drop-off areas
- End with the primary conversion action and next steps
- Use numbered steps that reflect the actual page flow and content order
- Dont be overly detailed, just enough to get the point across, 1 sentence per step.

ANALYSIS DEPTH REQUIRED: Your analysis must be comprehensive enough to justify a $10,000+ consulting fee. Every recommendation must be:
1. Backed by industry-specific conversion psychology principles.
2. Tailored to the identified page type and user intent.
3. Appropriate for the purchase behavior type (high vs low consideration).
4. Include detailed step-by-step implementation instructions in the "implementation" array.
5. Prioritized by conversion impact potential for this specific context.
6. Supported by industry-specific benchmarks and best practices.

IMPLEMENTATION REQUIREMENT: Every recommendation MUST include 3-5 specific, actionable implementation steps that they can execute immediately.

OUTPUT QUALITY: This analysis should read like a professional consulting report that demonstrates deep understanding of the specific industry, page type, and customer psychology.`,n=`COMPREHENSIVE CRO AUDIT REQUEST: Conduct a detailed, professional-grade conversion optimization analysis worth $10,000+ in consulting value.

=== PAGE CONTEXT ===
PAGE TITLE: ${e.title}
URL: ${e.url}
META DESCRIPTION: ${e.metaDescription}
VIEWPORT: ${e.pageMetadata.viewport.width}x${e.pageMetadata.viewport.height}
PAGE HEIGHT: ${e.pageMetadata.viewport.scrollHeight}px
MOBILE OPTIMIZED: ${e.pageMetadata.viewportMeta.includes("width=device-width")?"Yes":"No"}

=== COMPLETE PAGE CONTENT ===
${e.fullTextContent}

=== STRUCTURAL ANALYSIS ===
CONTENT HIERARCHY:
${e.structuredContent.headings.map(i=>{const l=i.position||{top:0},f=e.pageMetadata.viewport.height||800,C=l.top<f?"Above fold":l.top<f*2?"Mid-page":"Below fold";return`${i.tag.toUpperCase()}: "${i.text}" (${C})`}).join(`
`)}

INTERACTIVE ELEMENTS (Buttons, CTAs, Links):
${e.structuredContent.interactiveElements.map(i=>{const l=i.isAboveFold?"Above fold":"Below fold",f=i.position.width*i.position.height,C=f>8e3?"Large":f>3e3?"Medium":"Small";return`${i.elementType==="button"?"BUTTON":"LINK"} (${C}, ${l}): "${i.text}"${i.href?` -> ${i.href}`:""}`}).join(`
`)}

${((p=(r=e.structuredContent)==null?void 0:r.forms)==null?void 0:p.length)>0?`
CONVERSION FORMS:
${e.structuredContent.forms.map((i,l)=>`Form ${l+1}: ${i.totalFields||0} fields (${i.requiredFields||0} required), Action: "${i.action||"No action"}"`).join(`
`)}`:""}

${((u=(a=e.structuredContent)==null?void 0:a.lists)==null?void 0:u.length)>0?`
CONTENT LISTS:
${e.structuredContent.lists.map(i=>{var l;return`${((l=i.tag)==null?void 0:l.toUpperCase())||"UNKNOWN"}: ${i.itemCount||0} items`}).join(`
`)}`:""}

${((d=(c=e.structuredContent)==null?void 0:c.videos)==null?void 0:d.length)>0||((y=(h=e.structuredContent)==null?void 0:h.images)==null?void 0:y.filter(i=>i.isAnimated).length)>0?`
MEDIA ELEMENTS:
${((m=(A=e.structuredContent)==null?void 0:A.videos)==null?void 0:m.length)>0?e.structuredContent.videos.map(i=>{var C;const l=i.src.includes("youtube")?"YouTube":i.src.includes("vimeo")?"Vimeo":i.src.includes("wistia")?"Wistia":i.src.includes("loom")?"Loom":i.type==="video"?"Native Video":"Video",f=[i.autoplay?"autoplay":"",i.muted?"muted":"",i.controls?"has-controls":"no-controls",i.loop?"looping":""].filter(Boolean).join(", ");return`${(C=i.type)==null?void 0:C.toUpperCase()}: ${l} (${f}) - ${i.width}x${i.height}px - ${i.parentSection||"Unknown section"}`}).join(`
`):""}${((T=(g=e.structuredContent)==null?void 0:g.videos)==null?void 0:T.length)>0&&((S=(E=e.structuredContent)==null?void 0:E.images)==null?void 0:S.filter(i=>i.isAnimated).length)>0?`
`:""}${((b=(v=e.structuredContent)==null?void 0:v.images)==null?void 0:b.filter(i=>i.isAnimated).length)>0?`Animated Images (GIFs): ${e.structuredContent.images.filter(i=>i.isAnimated).map(i=>i.parentSection||"Unknown").join(", ")}`:""}`:""}
${((N=(O=e.structuredContent)==null?void 0:O.interactive)==null?void 0:N.length)>0?`
INTERACTIVE ELEMENTS:
${e.structuredContent.interactive.map(i=>{var l;return`${((l=i.type)==null?void 0:l.toUpperCase())||"CAROUSEL"}: ${i.itemCount||0} items${i.hasControls?" (Has navigation)":""}${i.hasDots?" (Has dots)":""} - ${i.parentSection||"Unknown section"}`}).join(`
`)}`:""}

PAGE FLOW:
${((P=(R=e.structuredContent)==null?void 0:R.sections)==null?void 0:P.slice(0,8).map((i,l)=>{var f;return`Section ${l+1}: "${((f=i.textPreview)==null?void 0:f.substring(0,80))||"No preview"}..."`}).join(`
`))||"NO PAGE SECTIONS"}

${($=(k=e.structuredContent)==null?void 0:k.stickyHeader)!=null&&$.exists?`
⚠️ STICKY HEADER ALREADY EXISTS - DO NOT RECOMMEND ADDING ONE ⚠️
Position Type: ${e.structuredContent.stickyHeader.positionType}
Total Height: ${e.structuredContent.stickyHeader.totalHeight}px
Element Count: ${e.structuredContent.stickyHeader.elementCount}
Contents: ${((M=e.structuredContent.stickyHeader.contents)==null?void 0:M.map(i=>`${i.tag.toUpperCase()} (${i.height}px)${i.ctas.length>0?` - CTAs: ${i.ctas.join(", ")}`:""}`).join(" | "))||"No content details available"}
`:`
⚠️ NO HEADER DETECTED BY CODE - VERIFY WITH SCREENSHOTS BEFORE RECOMMENDING ⚠️
Compare Screenshot #1 (top of page) with Screenshot #4-5 (mid-page).
If a header appears in BOTH screenshots, do NOT recommend adding a sticky header.
Only recommend a sticky header if NO persistent header is visible when scrolling.
`}

=== ANALYSIS REQUIREMENTS ===

CRITICAL REQUIREMENTS:
- Only analyze elements that actually exist on the page - do NOT invent or hallucinate content
- NEVER include percentage improvement estimates or conversion lift numbers
- Focus on unique, actionable insights - avoid repeating the same recommendations across sections
- If no forms exist, omit the forms section entirely
- Each recommendation should be distinct and non-overlapping to avoid redundancy
- Do NOT use em Dashes in the analysis


INTERACTIVE ELEMENT ANALYSIS:
- You are receiving ALL interactive elements (buttons and links) without pre-filtering
- Use the full page context with the screenshots to visually confirm, element size, position, and styling to determine:
  * Which are primary CTAs (likely large buttons above fold with action-oriented copy)
  * Which are secondary CTAs (smaller, less prominent, or below fold)
  * Which are navigation elements (links in header/footer, standard nav patterns)
  * Which are trust signals (Contact, About, Support in appropriate contexts)
  * Which are social proof (social media links, review platform links)
- Consider the business type and page type when classifying element importance

ANALYSIS STRUCTURE:

1. **CONTEXT ANALYSIS FIRST** (Mandatory)
   - Identify business type/industry and apply industry-specific expertise
   - Determine page type and adapt analysis framework accordingly  
   - Assess purchase behavior type (high vs low consideration) and tailor approach
   - Establish industry-specific benchmarks and best practices

2. **PAGE SUMMARY** 
   - Business type, audience, and conversion goals with industry context
   - Page type and its role in the conversion funnel
   - Purchase behavior analysis and implications
   - Detailed customer journey analysis: Start with how customers arrive at this page, then map each step they take through the page content toward conversion, including decision points and potential drop-off areas
   - Top 3 strengths and top 3 weaknesses

3. **VISUAL CRO ANALYSIS** (For Visual Analysis Only)
    ${s.length>0?`=== VISUAL ANALYSIS ===
    You have access to ${s.length>1?`${s.length} sequential screenshots of the complete page from top to bottom`:"a screenshot of the page"} to supplement the analysis. Use ${s.length>1?"these":"this"} to analyze:
    - Visual hierarchy and user flow
    - CTA prominence and placement
    - Design quality, consistency, and trust signals
    - Color scheme effectiveness
    - Overall visual polish
    
    IMPORTANT: When analyzing videos, carousels, and interactive elements:
    - Native video players may show a poster frame or first frame; this does NOT mean they're broken.
    - Videos with visible controls or play buttons are functional.
    - Carousels may appear static in screenshots but are functional if navigation controls are present.
    - Animated GIFs may appear as static images but are functional on the live page`:""}

   As a $10,000/day CRO auditor, provide dedicated visual conversion analysis:
   - VISUAL FLOW ANALYSIS: How does the eye naturally flow through the page? Do colors and content hierarchy guide users toward CTAs? Are there visual distractions that pull attention away from conversion goals?
   - COLOR & CONTRAST EVALUATION: How effective are the color choices for conversion? Is there sufficient contrast for readability and CTA prominence? Do colors create the right emotional response for the target audience?
   - CRITICAL VISUAL ISSUE: What's the single biggest visual problem preventing conversions? Focus on business impact and user behavior. Provide clear, non-technical solutions that marketers and executives can understand and implement. Avoid technical details like hex codes, pixel measurements, or CSS specifications. Instead, describe the problem in terms of user experience and business outcomes, then provide simple, actionable solutions that can be communicated to designers and developers, avoid repitition with other recommendations.
   - You should verify your ideas from Context Analysis to inform these recommendations.

4. **ACTIONABLE RECOMMENDATIONS** 
   - 5-7 prioritized, industry-specific recommendations with detailed step-by-step implementation
   - Each recommendation MUST include an "implementation" array with 3-5 specific, actionable steps
   - Psychological principles behind each recommendation (adapted for purchase behavior type)
   - Effort level and timeline for each
   - Industry-specific best practices and benchmarks
   - Compelling emotionally & logically charged copy suggestions
   - You should verify your ideas from Visual CRO Analysis to inform these recommendations

5. **QUICK WINS**
   - 3-5 high-impact, low-effort improvements that can be done immediately
   - Tailored to the specific page type and business model
   - Avoid repitition with other recommendations


CRITICAL: 
- Each recommendation MUST include a detailed "implementation" array with step-by-step instructions.
- You CANNOT include redundancies in the recommendations.

Return analysis as JSON with this ENHANCED structure:
{
  "starRating": 2,
  "pageSummary": {
    "businessType": "B2B SaaS - Project Management Software",
    "industryContext": "High-consideration B2B software purchase requiring trust building and detailed feature explanation",
    "pageType": "Pricing Page",
    "purchaseBehaviorType": "high-consideration",
    "primaryConversionGoal": "Upgrade to paid plan or start trial", 
    "targetAudience": "Team leaders and project managers at mid-size companies",
    "currentUserJourney": [
      "1. Arrive on page (likely from search for ADHD symptoms/clinics)",
      "2. Identify with common ADHD symptoms and challenges",
      "3. Understand the problem of undiagnosed ADHD and traditional care barriers", 
      "4. Learn how Frida provides a solution (online, accessible, affordable)",
      "5. Review social proof and success stories",
      "6. Understand the 'how it works' process",
      "7. Evaluate expert credentials and service offerings",
      "8. Consider pricing and FAQs",
      "9. Take the 'Free ADHD Symptoms Test' as a low-commitment first step"
    ],
    "keyStrengths": ["Clear pricing tiers", "Industry-standard features", "Professional design"],
    "criticalWeaknesses": ["Weak social proof for enterprise segment", "No risk mitigation messaging", "Missing implementation support details"]
  },
  "visualCROAnalysis": {
    "visualFlow": {
      "eyeFlowPath": "Hero → Value Prop → Social Proof → CTA",
      "flowScore": 7,
      "guidesToCTA": true,
      "distractions": ["Competing CTAs in sidebar", "Too many color variations"]
    },
    "colorContrast": {
      "ctaContrast": "Excellent - 4.8:1 ratio",
      "readability": "Good overall", 
      "emotionalResponse": "Trust-building blues with conversion-optimized orange CTAs",
      "contrastScore": 8
    },
    "criticalIssue": {
      "problem": "Primary CTA blends with background reducing click-through rates",
      "solution": "Make the main call-to-action button stand out with a contrasting color that draws attention. Use a bright, action-oriented color that creates visual separation from the background. Ensure the button text is clearly readable and the overall design encourages clicks.",
      "impact": "High - likely 15-20% conversion increase",
      "urgency": "Critical"
    }
  },
  "recommendations": [
    {
      "title": "Add Enterprise Social Proof Section",
      "priority": "critical",
      "issue": "B2B buyers need validation from similar companies before committing to paid plans",
      "solution": "Create dedicated section with enterprise customer logos, case studies, and ROI metrics specific to project management efficiency",
      "implementation": [
        "Step 1: Collect customer success metrics and testimonials from existing clients",
        "Step 2: Design a dedicated social proof section to place above the pricing table",
        "Step 3: Add customer logos, case studies, and specific ROI data points",
        "Step 4: Include industry-specific benchmarks and success metrics",
        "Step 5: Test placement and messaging for maximum impact"
      ],
      "psychologyBehind": "B2B high-consideration purchases require social proof from peers to reduce perceived risk and validate decision-making",
      "industryContext": "SaaS pricing pages convert 23% better with prominent customer logos and specific ROI metrics",
      "effort": 3,
      "timeline": "1-2 weeks"
    }
  ],
  "quickWins": [
    {
      "title": "Add Risk-Free Trial Messaging",
      "description": "Emphasize 'No credit card required' and 'Cancel anytime' messaging prominently near CTAs",
      "rationale": "Reduces commitment anxiety for high-consideration purchases",
      "effort": 1,
      "timeline": "Same day"
    }
  ],
  "executiveSummary": [
    "Context: B2B SaaS pricing page for high-consideration software purchase requiring trust and risk mitigation",
    "Key insight: Missing critical trust signals and implementation clarity needed for enterprise buyers",
    "Priority focus: Add enterprise social proof and implementation support messaging to reduce buyer anxiety",
    "Industry benchmark: Current approach missing 40% of conversion elements typical in high-converting B2B SaaS pricing pages"
  ],
  "copySuggestions": [
    {
      "section": "Primary CTA",
      "suggestion": "Start Free Trial - No Credit Card Required"
    },
    {
      "section": "Risk Mitigation", 
      "suggestion": "Join 2,500+ teams already saving 40% on project delivery time"
    }
  ]
}

STAR RATING CRITERIA:
⭐ (1 Star) - Major Issues: 5+ critical problems, missing basic conversion elements (clear value prop, primary CTA, trust signals), poor UX/mobile experience, not optimized for industry/page type
⭐⭐ (2 Stars) - Good Foundation: 4-5 significant opportunities, basic elements present but not optimized for industry/purchase behavior, decent user experience but missing key conversion triggers
⭐⭐⭐ (3 Stars) - Well Optimized: 1-3 minor improvements possible, strong industry-appropriate conversion fundamentals, good psychology implementation, well-designed for target audience and page type`;return t.provider==="gemini"?await j(o,n,s,t):await B(o,n,s,t)}async function j(e,t,s,o){var y,A,m,g,T;const n=o.geminiModel,r=o.geminiApiKey,a=[{text:`${e}

${t}`}];s.forEach(E=>{a.push({inline_data:{mime_type:"image/jpeg",data:E}})});const u={contents:[{parts:a}],generationConfig:{temperature:.3,maxOutputTokens:16384,responseMimeType:"application/json"}},c=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${n}:generateContent`,{method:"POST",headers:{"Content-Type":"application/json","x-goog-api-key":r},body:JSON.stringify(u)});if(!c.ok){const E=await c.text(),S=U(E);throw new Error(`Gemini API error (${c.status}): ${S}`)}const h=((T=(g=(m=(A=(y=(await c.json()).candidates)==null?void 0:y[0])==null?void 0:A.content)==null?void 0:m.parts)==null?void 0:g[0])==null?void 0:T.text)||"";if(h.length===0)throw new Error("Empty response from Gemini API");try{return JSON.parse(h)}catch(E){const S=L(h);if(S)try{return JSON.parse(S)}catch{}throw new Error(`Invalid JSON response from Gemini API: ${E instanceof Error?E.message:"Parse failed"}`)}}async function B(e,t,s,o){var h,y,A;const n=o.openaiModel,r=o.openaiApiKey,p=[{type:"text",text:`${e}

${t}`}];s.forEach(m=>{p.push({type:"image_url",image_url:{url:`data:image/jpeg;base64,${m}`,detail:"low"}})});const a={model:n,messages:[{role:"user",content:p}]};n.startsWith("gpt-5")?(a.max_completion_tokens=16384,a.response_format={type:"json_object"}):n.includes("gpt-4")||n.includes("gpt-3.5")?(a.max_tokens=16384,a.temperature=.3,a.response_format={type:"json_object"}):(a.max_tokens=16384,a.temperature=.3,a.response_format={type:"json_object"});const u=await fetch("https://api.openai.com/v1/chat/completions",{method:"POST",headers:{Authorization:`Bearer ${r}`,"Content-Type":"application/json"},body:JSON.stringify(a)});if(!u.ok){const m=await u.text(),g=U(m);throw new Error(`OpenAI API error (${u.status}): ${g}`)}const d=((A=(y=(h=(await u.json()).choices)==null?void 0:h[0])==null?void 0:y.message)==null?void 0:A.content)||"";if(d.length===0)throw new Error("Empty response from OpenAI API");try{return JSON.parse(d)}catch(m){const g=L(d);if(g)try{return JSON.parse(g)}catch{}throw new Error(`Invalid JSON response from OpenAI API: ${m instanceof Error?m.message:"Parse failed"}`)}}function L(e){try{let t=e.trim();if(!t.startsWith("{")){const p=t.indexOf("{");if(p===-1)return null;t=t.substring(p)}let s=0,o=0,n=!1,r=!1;for(let p=0;p<t.length;p++){const a=t[p];if(r){r=!1;continue}if(a==="\\"){r=!0;continue}if(a==='"'&&!r){n=!n;continue}n||(a==="{"?s++:a==="}"?s--:a==="["?o++:a==="]"&&o--)}if(n){const p=t.lastIndexOf('"');p>0&&(t=t.substring(0,p+1))}for(;o>0;)t+="]",o--;for(;s>0;)t+="}",s--;return JSON.parse(t),t}catch{return null}}async function D(e,t=.5){try{const s=Math.floor(e.length*.75),o=document.createElement("canvas"),n=o.getContext("2d");if(!n)throw new Error("Canvas context not available");const r=new Image;await new Promise((m,g)=>{r.onload=()=>m(),r.onerror=()=>g(new Error("Failed to load image for compression")),r.src=`data:image/png;base64,${e}`});const p=Math.sqrt(t),a=Math.floor(r.width*p),u=Math.floor(r.height*p);o.width=a,o.height=u,n.imageSmoothingEnabled=!0,n.imageSmoothingQuality="high",n.drawImage(r,0,0,a,u);const c=.5,h=o.toDataURL("image/jpeg",c).replace(/^data:image\/jpeg;base64,/,""),A=Math.floor(h.length*.75)/s;return h}catch{return e}}async function F({key:e,url:t,model:s,params:o}){try{await I(e,{state:"running",progress:{step:"Preparing analysis",pct:10}}),await I(e,{progress:{step:"Capturing page data",pct:15}});const n=await Y(t);await I(e,{progress:{step:"Capturing screenshots",pct:25}});const r=await z(o);await I(e,{progress:{step:"Analyzing with AI...",pct:40}});const p=await W({pageData:n,url:t,model:s,params:o,screenshots:r});await I(e,{progress:{step:"Finalizing analysis",pct:90}}),await I(e,{state:"succeeded",progress:{step:"Analysis complete",pct:100},result:p,completedAt:Date.now()}),setTimeout(async()=>{try{await chrome.runtime.sendMessage({type:"STORAGE_REMOVE",key:`job:${e}`})}catch{}},2*24*60*60*1e3)}catch(n){throw await I(e,{state:"failed",error:String(n instanceof Error?n.message:n),failedAt:Date.now()}),n}}async function G(e){try{const t=await chrome.runtime.sendMessage({type:"STORAGE_GET",key:`job:${e}`});if(t!=null&&t.ok)return t.data||{key:e,createdAt:Date.now(),updatedAt:Date.now()};throw new Error((t==null?void 0:t.error)||"Storage proxy failed")}catch{return{key:e,createdAt:Date.now(),updatedAt:Date.now()}}}async function I(e,t){try{const o={...await G(e),...t,updatedAt:Date.now()},n=await chrome.runtime.sendMessage({type:"STORAGE_SET",key:`job:${e}`,data:o});if(n!=null&&n.ok)return o;throw new Error((n==null?void 0:n.error)||"Storage proxy failed")}catch(s){throw s}}async function Y(e){try{const t=await chrome.runtime.sendMessage({type:"SCRAPE_PAGE",url:e});if(t!=null&&t.ok)return t.data;throw new Error((t==null?void 0:t.error)||"Page scraping failed")}catch(t){return{url:e,title:`Error scraping ${new URL(e).hostname}`,timestamp:Date.now(),metaDescription:"",fullHTML:"",fullTextContent:`Failed to scrape ${e}: ${t instanceof Error?t.message:"Unknown error"}`,pageMetadata:{viewport:{width:1920,height:1080,scrollHeight:2e3},viewportMeta:""},structuredContent:{headings:[],buttons:[],forms:[],links:[],lists:[],sections:[],images:[],stickyHeader:{exists:!1,type:null,height:0,elements:[]}}}}}async function z(e){try{const t=await chrome.runtime.sendMessage({type:"CAPTURE_SCREENSHOTS",params:e});return t!=null&&t.ok?t.screenshots:(t==null?void 0:t.screenshots)||[]}catch{return[]}}async function W({pageData:e,url:t,model:s,params:o,screenshots:n}){try{const r=await chrome.runtime.sendMessage({type:"STORAGE_SYNC_GET",key:"extension_settings"});if(!(r!=null&&r.ok))throw new Error("Failed to get settings via storage proxy");let a={...{provider:"openai",openaiModel:"gpt-5",geminiModel:"gemini-2.5-pro",fullPageScreenshot:!0,openaiApiKey:"",geminiApiKey:""},...r.data||{}};w.STORAGE;const{EncryptionManager:u}=await _(()=>import("./encryption.js"),["./encryption.js","./debug.js"],import.meta.url),c=await u.decryptSettings(a);if(w.STORAGE,w.API_CALLS,c.openaiApiKey&&typeof c.openaiApiKey!="string")throw new Error("OpenAI API key is corrupted in storage. Please go to extension settings and re-enter your API key.");if(c.geminiApiKey&&typeof c.geminiApiKey!="string")throw new Error("Gemini API key is corrupted in storage. Please go to extension settings and re-enter your API key.");if(c.openaiApiKey==="[object Object]")throw new Error("OpenAI API key is corrupted. Please clear extension data and re-enter your API key.");if(c.geminiApiKey==="[object Object]")throw new Error("Gemini API key is corrupted. Please clear extension data and re-enter your API key.");const d=c.provider==="gemini"?c.geminiApiKey:c.openaiApiKey;if(!d)throw new Error(`${c.provider==="gemini"?"Gemini":"OpenAI"} API key not configured`);if(typeof d!="string")throw new Error(`Invalid API key format: ${typeof d}. Expected string but got ${typeof d}.`);if(c.provider==="openai"){if(!d.startsWith("sk-")||d.length<20)throw new Error('Invalid OpenAI API key format. Key should start with "sk-" and be at least 20 characters long.')}else if(c.provider==="gemini"&&(!d.startsWith("AIza")||d.length<30))throw new Error('Invalid Gemini API key format. Key should start with "AIza" and be at least 30 characters long.');return w.API_CALLS,await H(e,c,n)}catch(r){throw new Error(`LLM analysis failed: ${r instanceof Error?r.message:"Unknown error"}`)}}
