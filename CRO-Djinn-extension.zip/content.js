class f{async scrapePage(){await this.waitForPageReady();const e=window.location.href,s=document.title,t=this.getMetaDescription(),n=document.documentElement.outerHTML,i=this.extractFullTextContent(),o=this.extractStructuredContent(),r=this.getPageMetadata();return{url:e,title:s,metaDescription:t,fullHTML:n,fullTextContent:i,structuredContent:o,pageMetadata:r,timestamp:Date.now()}}async waitForPageReady(){return new Promise(e=>{document.readyState==="complete"?setTimeout(e,100):document.addEventListener("DOMContentLoaded",()=>{setTimeout(e,100)})})}getMetaDescription(){const e=document.querySelector('meta[name="description"]');return(e==null?void 0:e.content)||""}extractFullTextContent(){var n;const e=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,{acceptNode:i=>{var a;const o=i.parentElement;if(!o||o.tagName==="SCRIPT"||o.tagName==="STYLE"||this.isTrackingElement(o)||!this.isVisible(o))return NodeFilter.FILTER_REJECT;const r=((a=i.textContent)==null?void 0:a.trim())||"";return this.isTrackingText(r)?NodeFilter.FILTER_REJECT:NodeFilter.FILTER_ACCEPT}});let s="",t;for(;t=e.nextNode();){const i=(n=t.textContent)==null?void 0:n.trim();i&&(s+=i+" ")}return this.cleanContent(s.trim())}extractStructuredContent(){const e=this.getHeadings(),s=this.getInteractiveElements(),t=this.getForms(),n=this.getImages(),i=this.getLists(),o=this.getVideos(),r=this.getInteractiveWidgets(),a=this.detectStickyHeader();return{headings:e,interactiveElements:s,forms:t,images:n,lists:i,videos:o,interactive:r,stickyHeader:a,sections:this.getSections()}}getHeadings(){const e=[];return document.querySelectorAll("h1, h2, h3, h4, h5, h6").forEach((t,n)=>{var o,r;const i=(o=t.textContent)==null?void 0:o.trim();if(i&&this.isVisible(t)){const a=t.getBoundingClientRect(),c=Math.round(a.top+window.scrollY);e.push({tag:((r=t.tagName)==null?void 0:r.toLowerCase())||"",text:i,visible:this.isVisible(t),position:{top:c},index:n})}}),e}getInteractiveElements(){const e=[],s=["button",'input[type="submit"]','input[type="button"]','[role="button"]',"a[href]"].join(", ");return document.querySelectorAll(s).forEach((n,i)=>{var u;const o=((u=n.textContent)==null?void 0:u.trim())||n.value||"";if(!o||!this.isVisible(n)||this.isTrackingElement(n)||this.isCookieConsentElement(o))return;const r=n.getBoundingClientRect(),a=window.getComputedStyle(n),c=n.tagName.toLowerCase(),g=c==="button"||n.getAttribute("role")==="button"||c==="input"&&["submit","button"].includes(n.type);e.push({text:o,elementType:g?"button":"link",tag:c,href:n.href||null,type:n.type||null,position:{top:Math.round(r.top+window.scrollY),left:Math.round(r.left+window.scrollX),width:Math.round(r.width),height:Math.round(r.height)},styles:{backgroundColor:a.backgroundColor,color:a.color,fontSize:a.fontSize,fontWeight:a.fontWeight,textDecoration:a.textDecoration,display:a.display},attributes:{class:n.className,id:n.id,target:n.target||null,ariaLabel:n.getAttribute("aria-label")},isAboveFold:r.top+window.scrollY<window.innerHeight,index:i})}),e}getForms(){const e=[];return document.querySelectorAll("form").forEach((t,n)=>{if(this.isVisible(t)){const i=Array.from(t.querySelectorAll("input, select, textarea")).map(o=>{var r;return{tag:((r=o.tagName)==null?void 0:r.toLowerCase())||"",type:o.type||"text",name:o.name||"",placeholder:o.placeholder||"",required:o.hasAttribute("required")}});e.push({action:t.action||"",method:t.method||"get",inputs:i,totalFields:i.length,requiredFields:i.filter(o=>o.required).length,index:n})}}),e}getImages(){const e=[];return document.querySelectorAll("img").forEach((t,n)=>{this.isVisible(t)&&(t.getBoundingClientRect(),e.push({src:t.src,alt:t.alt||"",title:t.title||"",hasSize:!!(t.naturalWidth&&t.naturalHeight),isAnimated:t.src.toLowerCase().includes(".gif")||t.src.toLowerCase().includes("giphy")||t.closest('[class*="anim"]')!==null,parentSection:this.getParentSectionIdentifier(t),index:n}))}),e}getVideos(){const e=[];return document.querySelectorAll('video, iframe[src*="youtube"], iframe[src*="vimeo"], iframe[src*="wistia"], iframe[src*="loom"]').forEach((t,n)=>{if(this.isVisible(t)){const i=t.tagName.toLowerCase()==="video",o=t.getBoundingClientRect();e.push({type:t.tagName.toLowerCase(),src:t.src||t.src||"",autoplay:t.hasAttribute("autoplay"),muted:t.hasAttribute("muted"),controls:i?t.hasAttribute("controls"):!0,loop:t.hasAttribute("loop"),poster:i?t.poster:null,width:Math.round(o.width),height:Math.round(o.height),parentSection:this.getParentSectionIdentifier(t),index:n})}}),e}getInteractiveWidgets(){const e=[];return document.querySelectorAll('[class*="carousel"], [class*="slider"], [class*="swiper"], [class*="slide-show"], [data-carousel], [data-slider], [class*="glide"], [class*="splide"], [class*="slick"]').forEach((t,n)=>{if(this.isVisible(t)){const i=t.querySelectorAll('[class*="slide"], [class*="item"], [class*="card"]').length;i>1&&e.push({type:"carousel",itemCount:i,hasControls:!!t.querySelector('[class*="prev"], [class*="next"], [class*="arrow"]'),hasDots:!!t.querySelector('[class*="dot"], [class*="pagination"]'),parentSection:this.getParentSectionIdentifier(t),index:n})}}),e}detectStickyHeader(){const e=[],s=document.querySelectorAll("*");for(const o of s){const a=window.getComputedStyle(o).position;if(a==="fixed"||a==="sticky"){const c=o.getBoundingClientRect(),g=c.height,u=c.top,d=o.tagName.toLowerCase(),p=d==="header"||d==="nav"||o.className.toLowerCase().includes("header")||o.className.toLowerCase().includes("nav")?200:50;g>20&&u<=p&&c.bottom>0&&this.isVisible(o)&&e.push({element:o,height:g,top:u})}}if(e.length===0)return{exists:!1,type:null,height:0,elements:[]};e.sort((o,r)=>Math.abs(o.top-r.top)<10?r.height-o.height:o.top-r.top);let t=0,n=0;for(const o of e){const r=o.element.getBoundingClientRect();r.top>=n-10&&(t+=r.height,n=r.bottom)}const i=e.map(({element:o})=>{var u;const r=o.tagName.toLowerCase(),a=((u=o.textContent)==null?void 0:u.trim().substring(0,200))||"",c=o.querySelectorAll('button, a[href], [role="button"]'),g=Array.from(c).filter(d=>this.isVisible(d)).map(d=>{var m;return(m=d.textContent)==null?void 0:m.trim()}).filter(d=>d&&d.length>0).slice(0,5);return{tag:r,textPreview:a,ctas:g,height:o.getBoundingClientRect().height}});return{exists:!0,type:e[0].element.tagName.toLowerCase(),positionType:window.getComputedStyle(e[0].element).position,totalHeight:Math.round(t),elementCount:e.length,contents:i}}getParentSectionIdentifier(e){var o;const s=e.closest('section, article, main, [class*="section"]');if(!s)return"header";const t=Array.from(document.querySelectorAll('section, article, main, [class*="section"]')).indexOf(s),n=s.querySelector("h1, h2, h3"),i=((o=n==null?void 0:n.textContent)==null?void 0:o.trim().substring(0,30))||"";return i?`Section ${t+1}: ${i}`:`Section ${t+1}`}getLists(){const e=[];return document.querySelectorAll("ul, ol").forEach((t,n)=>{var i;if(this.isVisible(t)){const o=Array.from(t.querySelectorAll("li")).map(r=>{var a;return((a=r.textContent)==null?void 0:a.trim())||""});e.push({tag:((i=t.tagName)==null?void 0:i.toLowerCase())||"",items:o.filter(r=>r.length>0),itemCount:o.length,index:n})}}),e}getSections(){const e=[];return document.querySelectorAll('section, article, main, header, footer, nav, aside, div[class*="section"], div[class*="container"]').forEach((t,n)=>{var i,o;if(this.isVisible(t)){t.getBoundingClientRect();const r=((i=t.textContent)==null?void 0:i.trim().substring(0,500))||"";r.length>20&&e.push({tag:((o=t.tagName)==null?void 0:o.toLowerCase())||"",class:t.className,id:t.id,textPreview:r,index:n})}}),e}getPageMetadata(){const e={width:window.innerWidth,height:window.innerHeight,scrollHeight:document.documentElement.scrollHeight,isMobile:window.innerWidth<768,hasVerticalScroll:document.documentElement.scrollHeight>window.innerHeight},s=document.querySelector('meta[name="viewport"]'),t={};return document.querySelectorAll("meta").forEach(n=>{const i=n.getAttribute("name")||n.getAttribute("property"),o=n.getAttribute("content");i&&o&&(t[i]=o)}),{viewport:e,viewportMeta:(s==null?void 0:s.content)||"",metaTags:t,timestamp:Date.now(),userAgent:navigator.userAgent,language:document.documentElement.lang||"en"}}isVisible(e){const s=window.getComputedStyle(e),t=e.getBoundingClientRect();return s.display!=="none"&&s.visibility!=="hidden"&&s.opacity!=="0"&&t.width>0&&t.height>0}getContrastLevel(e,s){if(!e||!s)return"unknown";const t=e.toLowerCase(),n=s.toLowerCase();return(t.includes("white")||t.includes("rgb(255"))&&(n.includes("black")||n.includes("rgb(0"))||(t.includes("black")||t.includes("rgb(0"))&&(n.includes("white")||n.includes("rgb(255"))?"high":"medium"}isTrackingElement(e){const s=(typeof e.id=="string"?e.id:"").toLowerCase(),t=(typeof e.className=="string"?e.className:"").toLowerCase();return["gtm","analytics","tracking","facebook","fbq","hotjar","segment","google-tag","ga-","utm_","cookie","consent","optanon"].some(i=>s.includes(i)||t.includes(i))||!!e.closest("script, style, noscript")}isTrackingText(e){if(typeof e!="string")return!1;const s=e.toLowerCase();return["window.___chunkmapping","window.___webpack","analytics.","fbq(","gtm.start","_hjsettings","google-analytics","googletagmanager","hotjar","segment.com","optanonwrapper","dataLayer"].some(n=>s.includes(n))}isCookieConsentElement(e){if(!e||typeof e!="string")return!1;const s=e.toLowerCase();return["accept all cookies","accept cookies","manage cookies","cookie preferences","manage consent","cookie settings","privacy settings","opt out of cookies","confirm my choices","reject all cookies"].some(n=>s===n||s.length<30&&s.includes(n))}cleanContent(e){return e=e.replace(/\.[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/g,""),e=e.replace(/\.section[a-f0-9-]+/g,""),e=e.replace(/\{[^}]*\}/g,""),e=e.replace(/window\.___[^;]+;?/g,""),e=e.replace(/\{\\?"[^"]*\\?":\[\\?"[^"]*\\?"\]/g,""),e=e.replace(/\b(fbq|gtag|analytics)\([^)]*\)/g,""),e=e.replace(/\s+/g," ").trim(),e}}async function y(){return await new f().scrapePage()}class h{static async hasConsent(e){try{const s=this.getConsentKey(e),t=await chrome.runtime.sendMessage({type:"STORAGE_GET",key:s});if(!(t!=null&&t.ok))return!1;const n=t.data;if(!n)return!1;const i=Date.now(),o=n.timestamp+this.CONSENT_EXPIRY_DAYS*24*60*60*1e3;return i>o?(await chrome.runtime.sendMessage({type:"STORAGE_REMOVE",key:s}),!1):n.granted}catch{return!1}}static async saveConsent(e,s){try{const t=this.getConsentKey(e),n={domain:e,granted:s,timestamp:Date.now()},i=await chrome.runtime.sendMessage({type:"STORAGE_SET",key:t,data:n});if(!(i!=null&&i.ok))throw new Error(`Failed to save consent: ${(i==null?void 0:i.error)||"Unknown error"}`)}catch(t){throw t}}static async showConsentDialog(e){return new Promise(s=>{const t=document.createElement("div");t.id="cro-consent-overlay",t.style.cssText=`
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.7);
        z-index: 999999;
        display: flex;
        align-items: center;
        justify-content: center;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      `;const n=document.createElement("div");n.style.cssText=`
        background: white;
        border-radius: 12px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        max-width: 500px;
        margin: 20px;
        overflow: hidden;
        animation: slideIn 0.3s ease-out;
      `,n.innerHTML=`
        <style>
          @keyframes slideIn {
            from { transform: translateY(-50px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
          }
        </style>
        <div style="padding: 24px;">
          <div style="display: flex; align-items: center; margin-bottom: 16px;">
            <div style="width: 40px; height: 40px; background: #1976d2; border-radius: 8px; display: flex; align-items: center; justify-content: center; margin-right: 12px;">
              <svg width="24" height="24" fill="white" viewBox="0 0 24 24">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
              </svg>
            </div>
            <h2 style="margin: 0; font-size: 18px; font-weight: 600; color: #333;">CRO Analysis Consent</h2>
          </div>
          
          <p style="margin: 0 0 16px 0; line-height: 1.5; color: #666;">
            CRO Djinn would like to analyze this page (<strong>${e}</strong>) to provide conversion optimization insights.
          </p>
          
          <div style="background: #f5f5f5; border-radius: 8px; padding: 16px; margin-bottom: 20px;">
            <h3 style="margin: 0 0 8px 0; font-size: 14px; font-weight: 600; color: #333;">We will collect:</h3>
            <ul style="margin: 0; padding-left: 16px; color: #666; font-size: 14px;">
              <li>Page content and structure</li>
              <li>Screenshots of the page layout</li>
              <li>Meta information (title, description)</li>
            </ul>
            <p style="margin: 8px 0 0 0; font-size: 12px; color: #888;">
              Data is processed locally and sent to AI services for analysis only. We do not store personal information.
            </p>
          </div>
          
          <div style="display: flex; gap: 12px; justify-content: flex-end;">
            <button id="cro-consent-deny" style="
              padding: 10px 20px;
              border: 1px solid #ddd;
              background: white;
              border-radius: 6px;
              cursor: pointer;
              font-size: 14px;
              font-weight: 500;
              color: #666;
            ">Decline</button>
            <button id="cro-consent-allow" style="
              padding: 10px 20px;
              border: none;
              background: #1976d2;
              color: white;
              border-radius: 6px;
              cursor: pointer;
              font-size: 14px;
              font-weight: 500;
            ">Allow Analysis</button>
          </div>
        </div>
      `,t.appendChild(n),document.body.appendChild(t);const i=n.querySelector("#cro-consent-allow"),o=n.querySelector("#cro-consent-deny");i.addEventListener("click",()=>{document.body.removeChild(t),s(!0)}),o.addEventListener("click",()=>{document.body.removeChild(t),s(!1)}),t.addEventListener("click",r=>{r.target===t&&(document.body.removeChild(t),s(!1))})})}static getConsentKey(e){return`${this.CONSENT_KEY_PREFIX}${e.replace(/[^a-zA-Z0-9]/g,"_")}`}}h.CONSENT_KEY_PREFIX="consent_";h.CONSENT_EXPIRY_DAYS=30;window.__croGenieContentScriptLoaded||(window.__croGenieContentScriptLoaded=!0,chrome.runtime.onMessage.addListener((l,e,s)=>l.action==="ping"?(s({success:!0,loaded:!0}),!1):l.action==="scrapePage"?(w(s),!0):!1));async function w(l){try{const e=window.location.hostname;if(!await h.hasConsent(e)){if(!await h.showConsentDialog(e)){l({success:!1,error:"User declined consent for data collection",code:"CONSENT_DENIED"});return}await h.saveConsent(e,!0)}const t=await y();l({success:!0,data:t})}catch(e){l({success:!1,error:e instanceof Error?e.message:"Unknown error occurred"})}}
