import{S as c}from"./storage.js";import{D as u}from"./debug.js";import"./encryption.js";class p{static async hasConsent(e){try{const t=this.getConsentKey(e),n=(await chrome.storage.local.get(t))[t];if(!n)return!1;const o=Date.now(),s=n.timestamp+this.CONSENT_EXPIRY_DAYS*24*60*60*1e3;return o>s?(await chrome.storage.local.remove(t),!1):n.granted}catch(t){return console.error("Error checking consent:",t),!1}}static async saveConsent(e,t){try{const i=this.getConsentKey(e),n={domain:e,granted:t,timestamp:Date.now()};await chrome.storage.local.set({[i]:n})}catch(i){throw console.error("Error saving consent:",i),i}}static async showConsentDialog(e){return new Promise(t=>{const i=document.createElement("div");i.style.cssText=`
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.7);
        z-index: 999999;
        display: flex;
        align-items: center;
        justify-content: center;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      `;const n=document.createElement("div");n.style.cssText=`
        background: white;
        border-radius: 8px;
        padding: 24px;
        max-width: 480px;
        margin: 20px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        text-align: center;
        line-height: 1.5;
      `,n.innerHTML=`
        <div style="margin-bottom: 16px;">
          <h3 style="margin: 0 0 12px 0; color: #1f2937; font-size: 18px;">
            🔒 Privacy Notice
          </h3>
          <p style="margin: 0; color: #4b5563; font-size: 14px;">
            CRO Djinn wants to analyze this page (<strong>${e}</strong>) to provide conversion optimization recommendations.
          </p>
        </div>
        
        <div style="background: #f3f4f6; padding: 16px; border-radius: 6px; margin: 16px 0; text-align: left;">
          <p style="margin: 0 0 8px 0; font-weight: 600; color: #374151; font-size: 13px;">
            What data will be collected:
          </p>
          <ul style="margin: 0; padding-left: 20px; color: #6b7280; font-size: 12px;">
            <li>Page content and structure</li>
            <li>Button and form elements</li>
            <li>Page screenshots (if enabled)</li>
          </ul>
          <p style="margin: 8px 0 0 0; color: #6b7280; font-size: 12px;">
            Data is sent to AI services (OpenAI/Google) for analysis and stored locally on your device.
          </p>
        </div>

        <div style="display: flex; gap: 12px; justify-content: center;">
          <button id="consent-deny" style="
            background: #e5e7eb;
            color: #374151;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
          ">
            Don't Analyze
          </button>
          <button id="consent-allow" style="
            background: #3b82f6;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
          ">
            Allow Analysis
          </button>
        </div>
        
        <p style="margin: 16px 0 0 0; color: #9ca3af; font-size: 11px;">
          Consent expires in 30 days. You can manage data in the extension settings.
        </p>
      `,i.appendChild(n),document.body.appendChild(i);const o=n.querySelector("#consent-allow"),s=n.querySelector("#consent-deny");o.addEventListener("click",()=>{document.body.removeChild(i),t(!0)}),s.addEventListener("click",()=>{document.body.removeChild(i),t(!1)}),i.addEventListener("click",r=>{r.target===i&&(document.body.removeChild(i),t(!1))});const a=r=>{r.key==="Escape"&&(document.body.removeChild(i),document.removeEventListener("keydown",a),t(!1))};document.addEventListener("keydown",a)})}static async clearAllConsents(){try{const e=await chrome.storage.local.get(),t=Object.keys(e).filter(i=>i.startsWith(this.CONSENT_KEY_PREFIX));t.length>0&&await chrome.storage.local.remove(t)}catch(e){throw console.error("Error clearing consents:",e),e}}static async getGrantedConsents(){try{const e=await chrome.storage.local.get(),t=[];for(const[i,n]of Object.entries(e))if(i.startsWith(this.CONSENT_KEY_PREFIX)){const o=n;o.granted&&t.push(o.domain)}return t}catch(e){return console.error("Error getting granted consents:",e),[]}}static getConsentKey(e){return`${this.CONSENT_KEY_PREFIX}${e}`}static getDomainFromUrl(e){try{return new URL(e).hostname}catch{return e}}}p.CONSENT_KEY_PREFIX="consent_";p.CONSENT_EXPIRY_DAYS=30;class f{constructor(){this.form=null,this.providerSelect=null,this.openaiApiKeyInput=null,this.geminiApiKeyInput=null,this.openaiModelSelect=null,this.geminiModelSelect=null,this.fullPageScreenshotCheckbox=null,this.openaiConfig=null,this.geminiConfig=null,this.saveButton=null,this.cacheCountElement=null,this.consentsCountElement=null,this.initializeOptions()}async initializeOptions(){try{this.setupElements(),this.setupEventListeners(),await this.loadSettings(),await this.updateCacheInfo(),await this.updatePrivacyInfo()}catch(e){console.error("Failed to initialize options:",e),this.showError("Failed to load settings")}}setupElements(){if(this.providerSelect=document.getElementById("provider-select"),this.openaiApiKeyInput=document.getElementById("openai-api-key"),this.geminiApiKeyInput=document.getElementById("gemini-api-key"),this.openaiModelSelect=document.getElementById("openai-model"),this.geminiModelSelect=document.getElementById("gemini-model"),this.fullPageScreenshotCheckbox=document.getElementById("full-page-screenshot"),this.openaiConfig=document.getElementById("openai-config"),this.geminiConfig=document.getElementById("gemini-config"),this.saveButton=document.getElementById("save-button"),this.cacheCountElement=document.getElementById("cache-count"),this.consentsCountElement=document.getElementById("consents-count"),!this.providerSelect||!this.openaiApiKeyInput||!this.geminiApiKeyInput||!this.openaiModelSelect||!this.geminiModelSelect||!this.fullPageScreenshotCheckbox||!this.saveButton||!this.openaiConfig||!this.geminiConfig)throw new Error("Required form elements not found")}setupEventListeners(){var o,s,a,r;(o=this.saveButton)==null||o.addEventListener("click",l=>{l.preventDefault(),this.saveSettings()}),(s=this.providerSelect)==null||s.addEventListener("change",()=>{this.handleProviderChange()});const e=document.getElementById("clear-cache-button");e==null||e.addEventListener("click",()=>{this.clearCache()});const t=document.getElementById("clear-consents-button");t==null||t.addEventListener("click",()=>{this.clearConsents()});const i=document.getElementById("clear-all-data-button");i==null||i.addEventListener("click",()=>{this.clearAllData()});const n=document.getElementById("diagnostic-button");n&&n.addEventListener("click",()=>{this.runDiagnostics()}),(a=this.openaiApiKeyInput)==null||a.addEventListener("input",()=>{this.validateForm()}),(r=this.geminiApiKeyInput)==null||r.addEventListener("input",()=>{this.validateForm()}),document.addEventListener("keydown",l=>{l.key==="Enter"&&(l.ctrlKey||l.metaKey)&&this.saveSettings()})}handleProviderChange(){var t,i,n,o,s;const e=(t=this.providerSelect)==null?void 0:t.value;e==="openai"?((i=this.openaiConfig)==null||i.classList.remove("hidden"),(n=this.geminiConfig)==null||n.classList.add("hidden")):e==="gemini"&&((o=this.openaiConfig)==null||o.classList.add("hidden"),(s=this.geminiConfig)==null||s.classList.remove("hidden")),this.validateForm()}async loadSettings(){try{const e=await c.getSettings();this.providerSelect&&(this.providerSelect.value=e.provider||"openai"),this.openaiApiKeyInput&&(this.openaiApiKeyInput.value=e.openaiApiKey||""),this.geminiApiKeyInput&&(this.geminiApiKeyInput.value=e.geminiApiKey||""),this.openaiModelSelect&&(this.openaiModelSelect.value=e.openaiModel||"gpt-5"),this.geminiModelSelect&&(this.geminiModelSelect.value=e.geminiModel||"gemini-2.5-pro"),this.fullPageScreenshotCheckbox&&(this.fullPageScreenshotCheckbox.checked=e.fullPageScreenshot??!0),this.handleProviderChange(),this.validateForm()}catch(e){console.error("Failed to load settings:",e),this.showError("Failed to load saved settings")}}async saveSettings(){var e,t,i,n,o,s;if(this.validateForm())try{this.setLoading(!0),this.hideMessages();const a=((e=this.providerSelect)==null?void 0:e.value)||"openai",r=await c.getSettings(),l=a!=="openai"?r.openaiApiKey:"",d=a!=="gemini"?r.geminiApiKey:"";if(l&&(typeof l!="string"||l==="[object Object]"))throw console.error("🔧 CORRUPTION DETECTED in preserved OpenAI key:",l),new Error("Stored OpenAI API key is corrupted. Please re-enter it on the OpenAI provider settings.");if(d&&(typeof d!="string"||d==="[object Object]"))throw console.error("🔧 CORRUPTION DETECTED in preserved Gemini key:",d),new Error("Stored Gemini API key is corrupted. Please re-enter it on the Gemini provider settings.");const h={provider:a,openaiApiKey:a==="openai"?((t=this.openaiApiKeyInput)==null?void 0:t.value.trim())||"":l,geminiApiKey:a==="gemini"?((i=this.geminiApiKeyInput)==null?void 0:i.value.trim())||"":d,openaiModel:((n=this.openaiModelSelect)==null?void 0:n.value)||"gpt-5",geminiModel:((o=this.geminiModelSelect)==null?void 0:o.value)||"gemini-2.5-pro",fullPageScreenshot:((s=this.fullPageScreenshotCheckbox)==null?void 0:s.checked)||!1};u.STORAGE;const g=a==="openai"?h.openaiApiKey:h.geminiApiKey;if(!this.isValidApiKey(g,a)){const y=a==="openai"?"OpenAI":"Gemini";throw new Error(`Please enter a valid ${y} API key`)}await this.testApiKey(g,a==="openai"?h.openaiModel:h.geminiModel,a),await c.saveSettings(h),this.showSuccess("Settings saved successfully!")}catch(a){console.error("Failed to save settings:",a);const r=a instanceof Error?a.message:"Failed to save settings";this.showError(r)}finally{this.setLoading(!1)}}async testApiKey(e,t,i){var n,o;if(i==="openai"){const s=await fetch("https://api.openai.com/v1/models",{method:"GET",headers:{Authorization:`Bearer ${e}`,"Content-Type":"application/json"}});if(!s.ok)throw s.status===401?new Error("Invalid OpenAI API key. Please check your key."):s.status===429?new Error("OpenAI API rate limit exceeded. Please try again later."):new Error(`OpenAI API test failed (${s.status}). Please check your API key.`);(((n=(await s.json()).data)==null?void 0:n.map(l=>l.id))||[]).includes(t)||console.warn(`OpenAI model ${t} not found in available models. Using anyway.`)}else{const s=await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${e}`,{method:"GET",headers:{"Content-Type":"application/json"}});if(!s.ok)throw s.status===401||s.status===403?new Error("Invalid Gemini API key. Please check your key."):s.status===429?new Error("Gemini API rate limit exceeded. Please try again later."):new Error(`Gemini API test failed (${s.status}). Please check your API key.`);(((o=(await s.json()).models)==null?void 0:o.map(l=>l.name.split("/").pop()))||[]).includes(t)||console.warn(`Gemini model ${t} not found in available models. Using anyway.`)}}async updateCacheInfo(){try{const e=await c.getCacheSize();this.cacheCountElement&&(this.cacheCountElement.textContent=`${e} audits`)}catch(e){console.error("Failed to get cache info:",e),this.cacheCountElement&&(this.cacheCountElement.textContent="Unknown")}}async clearCache(){try{if(!confirm("Are you sure you want to clear all cached audit results? This action cannot be undone."))return;await c.clearCache(),await this.updateCacheInfo(),this.showSuccess("Cache cleared successfully!")}catch(e){console.error("Failed to clear cache:",e),this.showError("Failed to clear cache")}}async updatePrivacyInfo(){try{const e=await p.getGrantedConsents();this.consentsCountElement&&(this.consentsCountElement.textContent=`${e.length} sites`)}catch(e){console.error("Failed to get privacy info:",e),this.consentsCountElement&&(this.consentsCountElement.textContent="Unknown")}}async clearConsents(){try{if(!confirm("Are you sure you want to clear all site consents? You will be prompted for consent again on all websites."))return;await p.clearAllConsents(),await this.updatePrivacyInfo(),this.showSuccess("Site consents cleared successfully!")}catch(e){console.error("Failed to clear consents:",e),this.showError("Failed to clear site consents")}}async clearAllData(){try{if(!confirm(`⚠️ WARNING: This will delete ALL extension data including API keys, settings, cached results, and site consents. This action cannot be undone.

Are you sure you want to continue?`))return;await Promise.all([p.clearAllConsents(),c.clearCache(),chrome.storage.sync.clear(),chrome.storage.local.clear()]),this.showSuccess("All extension data deleted successfully! Page will reload to reset settings."),setTimeout(()=>{window.location.reload()},2e3)}catch(e){console.error("Failed to clear all data:",e),this.showError("Failed to delete all extension data")}}async runDiagnostics(){try{console.log("🔍 Running settings diagnostics...");const t=(await chrome.storage.sync.get("extension_settings")).extension_settings;console.log("Raw stored settings:",t);const i=await c.getSettings();u.STORAGE;const n=c.validateSettings(i);console.log("Settings validation:",n);const o=i.provider,s=o==="openai"?i.openaiApiKey:i.geminiApiKey,a=this.isValidApiKey(s,o);let r=`🔍 Diagnostics Results:

`;if(r+=`Provider: ${o}
`,r+=`Current API Key Valid: ${a?"✅ YES":"❌ NO"}
`,r+=`Current API Key Length: ${(s==null?void 0:s.length)||0}

`,a?(r+=`✅ Your API key appears to be valid.
`,r+="If you're still having issues, there might be a network or API quota problem."):(r+=`❌ Issue Detected: Your ${o.toUpperCase()} API key appears to be corrupted.

`,r+=`Recommended Actions:
`,r+=`1. Re-enter your API key manually
`,r+=`2. Make sure it starts with "${o==="openai"?"sk-":"AIza"}"
`,r+=`3. Or clear all data and start fresh

`,r+="Check browser console for detailed logs."),alert(r),!a&&confirm("Would you like to attempt automatic repair of the corrupted API key? If that fails, we can clear all settings and start fresh."))try{await this.attemptSettingsRepair(),this.showSuccess("Settings repair attempted. Please check if your API key is working now.")}catch(d){console.error("Automatic repair failed:",d),confirm("Automatic repair failed. Would you like to clear all corrupted settings? This will reset your API keys and you'll need to re-enter them.")&&(await chrome.runtime.sendMessage({type:"CLEAR_CORRUPTED_SETTINGS"}),this.showSuccess("Corrupted settings cleared. Please re-enter your API keys."),setTimeout(()=>{window.location.reload()},1500))}}catch(e){console.error("Diagnostics failed:",e),this.showError("Failed to run diagnostics. Check console for details.")}}async attemptSettingsRepair(){console.log("🔧 Attempting automatic settings repair...");try{const t=(await chrome.storage.sync.get("extension_settings")).extension_settings;if(!t)throw new Error("No settings found to repair");console.log("🔧 Raw settings before repair:",t);const i={...t};let n=!1;i.openaiApiKey&&typeof i.openaiApiKey!="string"&&(console.log("🔧 Repairing OpenAI API key from:",typeof i.openaiApiKey),i.openaiApiKey=String(i.openaiApiKey),n=!0),i.geminiApiKey&&typeof i.geminiApiKey!="string"&&(console.log("🔧 Repairing Gemini API key from:",typeof i.geminiApiKey),i.geminiApiKey=String(i.geminiApiKey),n=!0),n?(await chrome.storage.sync.set({extension_settings:i}),console.log("✅ Settings repair complete"),await this.loadSettings()):console.log("ℹ️ No repairs needed - settings appear to be valid")}catch(e){throw console.error("🔧 Settings repair failed:",e),e}}validateForm(){var i,n,o;const e=(i=this.providerSelect)==null?void 0:i.value;let t=!1;if(e==="openai"){const s=((n=this.openaiApiKeyInput)==null?void 0:n.value.trim())||"";t=this.isValidApiKey(s,"openai")}else if(e==="gemini"){const s=((o=this.geminiApiKeyInput)==null?void 0:o.value.trim())||"";t=this.isValidApiKey(s,"gemini")}return this.saveButton&&(this.saveButton.disabled=!t),t}isValidApiKey(e,t){return!e||e.length===0?!1:t==="openai"?e.startsWith("sk-")&&e.length>20:e.startsWith("AIza")&&e.length>30}setLoading(e){if(!this.saveButton)return;const t=this.saveButton.querySelector(".button-text"),i=this.saveButton.querySelector(".loading-spinner");e?(this.saveButton.disabled=!0,t==null||t.classList.add("hidden"),i==null||i.classList.remove("hidden")):(this.saveButton.disabled=!1,t==null||t.classList.remove("hidden"),i==null||i.classList.add("hidden"))}showSuccess(e){this.hideMessages();const t=document.getElementById("success-message");t&&(t.classList.remove("hidden"),setTimeout(()=>{t.classList.add("hidden")},4e3))}showError(e){this.hideMessages();const t=document.getElementById("error-message"),i=document.getElementById("error-text");t&&i&&(i.textContent=e,t.classList.remove("hidden"))}hideMessages(){const e=document.getElementById("success-message"),t=document.getElementById("error-message");e==null||e.classList.add("hidden"),t==null||t.classList.add("hidden")}}document.addEventListener("DOMContentLoaded",()=>{new f});
